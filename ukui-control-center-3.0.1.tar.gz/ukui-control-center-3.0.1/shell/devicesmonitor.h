#ifndef DEVICESMONITOR_H
#define DEVICESMONITOR_H

bool isExitTouchScreen();

#endif // DEVICESMONITOR_H
