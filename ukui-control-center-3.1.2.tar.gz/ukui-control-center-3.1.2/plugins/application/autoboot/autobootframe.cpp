#include "autobootframe.h"

AutobootFrame::AutobootFrame()
{

}
