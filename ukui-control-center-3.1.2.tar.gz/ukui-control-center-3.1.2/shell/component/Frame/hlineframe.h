#ifndef _HLINEFRAME_H_
#define _HLINEFRAME_H_
#include <QFrame>

class HLineFrame : public QFrame
{
public:
    HLineFrame(QWidget *parent = nullptr);
    ~HLineFrame();
};



#endif
