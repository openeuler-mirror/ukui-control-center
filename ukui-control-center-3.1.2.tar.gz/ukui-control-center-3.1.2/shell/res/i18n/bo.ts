<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="465"/>
        <source>System Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="466"/>
        <source>Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="467"/>
        <source>Version Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="528"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Status</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="530"/>
        <source>DateRes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="470"/>
        <source>Wechat code scanning obtains HP professional technical support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="471"/>
        <source>See more about Kylin Tianqi edu platform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="403"/>
        <source>&lt;&lt;Protocol&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="207"/>
        <source>HostName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="347"/>
        <source>Privacy and agreement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="356"/>
        <source>Send optional diagnostic data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="358"/>
        <source>By sending us diagnostic data, improve the system experience and solve your problems faster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="404"/>
        <source>and</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="405"/>
        <source>&lt;&lt;Privacy&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="492"/>
        <source>Learn more HP user manual&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="502"/>
        <source>See user manual&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="867"/>
        <source>expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="871"/>
        <source>Extend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="1007"/>
        <source>The system needs to be restarted to set the HostName, whether to reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="1008"/>
        <source>Reboot Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="1009"/>
        <source>Reboot Later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="787"/>
        <location filename="../../../plugins/system/about/about.cpp" line="796"/>
        <location filename="../../../plugins/system/about/about.cpp" line="1142"/>
        <source>avaliable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="516"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/version</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="663"/>
        <location filename="../../../plugins/system/about/about.cpp" line="665"/>
        <source>Copyright © 2009-2021 KylinSoft. All rights reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="518"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Kernel</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="520"/>
        <source>CPU</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/CPU</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="522"/>
        <source>Memory</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Memory</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="468"/>
        <location filename="../../../plugins/system/about/about.cpp" line="794"/>
        <source>Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="524"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Desktop</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="526"/>
        <source>User</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/User</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="529"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="64"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="579"/>
        <source>Inactivated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="581"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="586"/>
        <source>Activated</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddAutoBoot</name>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="220"/>
        <source>Add autoboot program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="224"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="225"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="245"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="226"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="340"/>
        <source>desktop file not exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="243"/>
        <source>select autoboot desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="166"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="221"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="167"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="222"/>
        <source>Exec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="168"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="223"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="236"/>
        <source>Desktop files(*.desktop)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="244"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="291"/>
        <source>desktop file not allowed add</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddBtn</name>
    <message>
        <location filename="../../../commonComponent/AddBtn/addbtn.cpp" line="19"/>
        <location filename="../../../libukcc/widgets/AddBtn/addbtn.cpp" line="19"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddNetBtn</name>
    <message>
        <location filename="../../../plugins/network/netconnect/addnetbtn.cpp" line="18"/>
        <source>Add WiredNetork</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppUpdateWid</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="73"/>
        <source>Lack of local disk space!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="79"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="102"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="399"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="622"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="693"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="859"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="96"/>
        <source>Network abnormal!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="111"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="127"/>
        <source>Download failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="113"/>
        <source>failed to get from the source!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="129"/>
        <source>The download cache has been removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="175"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="724"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="837"/>
        <source>Ready to install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="288"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="291"/>
        <source>Being installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="302"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="304"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="305"/>
        <source>Update succeeded , It is recommended that you restart later!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="309"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="311"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="312"/>
        <source>Update succeeded , It is recommended that you log out later and log in again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="315"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="324"/>
        <source>Update succeeded!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="333"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="343"/>
        <source>Update failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="336"/>
        <source>Failure reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="393"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="609"/>
        <source>details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="442"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="508"/>
        <source>Update log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="488"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="489"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="494"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="509"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="697"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="698"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="702"/>
        <source>Newest:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="517"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="523"/>
        <source>Download size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="550"/>
        <source>Current version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="603"/>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="628"/>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="631"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="643"/>
        <source>A single update will not automatically backup the system, if you want to backup, please click Update All.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="644"/>
        <source>Prompt information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="647"/>
        <source>Do not backup, continue to update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="648"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="720"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="649"/>
        <source>Cancel update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="653"/>
        <source>This time will no longer prompt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="728"/>
        <source>Calculate the download progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="739"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="746"/>
        <source>Get depends failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="796"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="799"/>
        <source>In the update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="918"/>
        <source>No content.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AptProxyDialog</name>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="25"/>
        <source>Set Apt Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="42"/>
        <source>Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="60"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="81"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="85"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Area</name>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="26"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="43"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="169"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="353"/>
        <source>Current Region</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Current Region</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="363"/>
        <source>First Day Of The Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="277"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="355"/>
        <source>Calendar</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Calendar</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="56"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="160"/>
        <source>Language Format</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Regional Format</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="446"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="359"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Date</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="529"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="361"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="568"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="162"/>
        <source>System Language</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/system language</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="602"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="366"/>
        <source>lunar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="369"/>
        <source>monday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="217"/>
        <source>US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="218"/>
        <source>CN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="165"/>
        <source>Language for system windows,menus and web pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="357"/>
        <source>First Day Of Week</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/First Day Of Week</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="363"/>
        <source>solar calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="370"/>
        <source>sunday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="381"/>
        <source>12 Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="382"/>
        <source>24 Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="492"/>
        <source>Modify the current region need to logout to take effect, whether to logout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="493"/>
        <source>Logout later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="494"/>
        <source>Logout now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="496"/>
        <source>Modify the first language need to reboot to take effect, whether to reboot?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="497"/>
        <source>Reboot later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="498"/>
        <source>Reboot now</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Audio</name>
    <message>
        <location filename="../../../plugins/devices/audio/audio.ui" line="26"/>
        <location filename="../../../plugins/devices/audio/audio.cpp" line="27"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutoBoot</name>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="556"/>
        <source>Autoboot Settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Autoboot Settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="66"/>
        <source>Auto Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="223"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="545"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Add</extra-contents_path>
    </message>
</context>
<context>
    <name>Backup</name>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="53"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="45"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="101"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="69"/>
        <source>Back up your files to other drives, and when the original files are lost, damaged, or deleted, 
you can restore them to ensure the integrity of your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="113"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="104"/>
        <source>Begin backup</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/backup/Begin backup</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="157"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="102"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="173"/>
        <source>View a list of backed-upfiles to backed up files to the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="213"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="106"/>
        <source>Begin restore</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/backup/Begin restore</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/backup.ui" line="144"/>
        <source>All data stored on the computer will be permanently erased,and the system will revert to 
                                its original factory state when this operation is completed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/backup.ui" line="213"/>
        <location filename="../../../plugins/system/backup_intel/backup.cpp" line="76"/>
        <source>Clear and restore</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/backup/Clear and restore</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/backup.cpp" line="42"/>
        <source>System Recovery</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BiometricEnrollDialog</name>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.ui" line="290"/>
        <source>Continue to enroll </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.ui" line="322"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="121"/>
        <source>FingerPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="123"/>
        <source>Fingervein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="125"/>
        <source>Iris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="127"/>
        <source>Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="129"/>
        <source>VoicePrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="139"/>
        <source>Enroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="142"/>
        <source>Verify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="145"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="173"/>
        <source>Permission is required.
Please authenticate yourself to continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="197"/>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="367"/>
        <source>Enroll successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="263"/>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="369"/>
        <source>Verify successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="266"/>
        <source>Not Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="487"/>
        <source>D-Bus calling error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="496"/>
        <source>Device is busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="500"/>
        <source>No such device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricenroll.cpp" line="504"/>
        <source>Permission denied</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BiometricMoreInfoDialog</name>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="76"/>
        <source>Biometrics </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="166"/>
        <source>Default device </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="208"/>
        <source>Verify Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="215"/>
        <source>Bus Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="222"/>
        <source>Device Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="243"/>
        <source>Storage Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.ui" line="250"/>
        <source>Identification Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="77"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="77"/>
        <source>Unconnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="126"/>
        <source>FingerPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="128"/>
        <source>Fingervein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="130"/>
        <source>Iris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="132"/>
        <source>Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="134"/>
        <source>VoicePrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="143"/>
        <source>Hardware Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="145"/>
        <source>Software Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="147"/>
        <source>Mix Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="149"/>
        <source>Other Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="157"/>
        <source>Device Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="159"/>
        <source>OS Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="161"/>
        <source>Mix Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="169"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="171"/>
        <source>USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="173"/>
        <source>PCIE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="175"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="177"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="185"/>
        <source>Hardware Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="187"/>
        <source>Software Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="189"/>
        <source>Mix Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricmoreinfo.cpp" line="191"/>
        <source>Other Identification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Biometrics</name>
    <message>
        <location filename="../../../plugins/account/biometrics/biometrics.cpp" line="24"/>
        <source>Biometrics</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BiometricsWidget</name>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="35"/>
        <source>Biometric password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="89"/>
        <source>Account password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="109"/>
        <source>Change password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="171"/>
        <source>Enable biometrics </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="191"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="271"/>
        <source>Device Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.ui" line="367"/>
        <source>Device Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.cpp" line="73"/>
        <source>Add biometric feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.cpp" line="233"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.cpp" line="235"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.cpp" line="237"/>
        <source>root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricswidget.cpp" line="755"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlueToothMain</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="62"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="88"/>
        <source>Turn on :</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Turn on Bluetooth</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="118"/>
        <source>Bluetooth adapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="146"/>
        <source>Show icon on taskbar</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Show icon on taskbar</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="176"/>
        <source>Discoverable by nearby Bluetooth devices</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Discoverable</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="209"/>
        <source>My Devices</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/My Devices</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="226"/>
        <source>Other Devices</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Other Devices</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="320"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="321"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="322"/>
        <source>Peripherals</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="323"/>
        <source>PC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="324"/>
        <source>Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="325"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="689"/>
        <source>Bluetooth adapter is not detected!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlueToothMainWindow</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="51"/>
        <source>Bluetooth adapter is abnormal !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="82"/>
        <source>Bluetooth adapter not detected !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="132"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="155"/>
        <source>Turn on :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="184"/>
        <source>Adapter List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="211"/>
        <source>Show icon on taskbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="237"/>
        <source>Discoverable by nearby Bluetooth devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="264"/>
        <source>My Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmainwindow.cpp" line="280"/>
        <source>Other Devices</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bluetooth</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetooth.cpp" line="6"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BluetoothNameLabel</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="37"/>
        <source>Double-click to change the device name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="93"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="187"/>
        <source>Can now be found as &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="104"/>
        <source>Tip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="105"/>
        <source>The length of the device name does not exceed %1 characters !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrightnessFrame</name>
    <message>
        <location filename="../../../plugins/system/display/brightnessFrame.cpp" line="39"/>
        <source>Failed to get the brightness information of this monitor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeFaceIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="85"/>
        <source>Change User Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="277"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="385"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="470"/>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="357"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="505"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="352"/>
        <source>select custom face file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="353"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="354"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="355"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="356"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="371"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="371"/>
        <source>The avatar is larger than 2M, please choose again</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeFeatureName</name>
    <message>
        <location filename="../../../plugins/account/biometrics/changefeaturename.ui" line="26"/>
        <source>Change Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changefeaturename.ui" line="90"/>
        <source>Feature name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changefeaturename.ui" line="181"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changefeaturename.ui" line="200"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changefeaturename.cpp" line="24"/>
        <source>Name already in use, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="79"/>
        <source>User Group Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="194"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="244"/>
        <source>User group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="291"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="334"/>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="342"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="334"/>
        <source>Invalid Id!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="337"/>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="345"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="342"/>
        <source>Invalid Group Name!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeGroupIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.ui" line="119"/>
        <source>User Group Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.ui" line="149"/>
        <source>User groups available in the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.cpp" line="119"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePhoneIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="77"/>
        <source>changephone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="190"/>
        <source>Please input old phone num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="242"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="429"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="452"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="366"/>
        <source>GetVerifyCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="586"/>
        <source>submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="53"/>
        <source>Change Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="91"/>
        <source>Phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="92"/>
        <source>SMS verification code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="124"/>
        <source>Please input old phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="125"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="128"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="251"/>
        <source>Please enter new mobile number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="129"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="252"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="145"/>
        <source>changed success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="146"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="322"/>
        <source>You have successfully modified your phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="197"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="221"/>
        <source>Recapture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="211"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="271"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="306"/>
        <source>Network connection failure, please check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="231"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="256"/>
        <source>GetCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="264"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="296"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="325"/>
        <source>Phone is lock,try again in an hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="267"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="299"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="328"/>
        <source>Phone code is wrong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="274"/>
        <source>Current login expired,using wechat code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="277"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="309"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="335"/>
        <source>Unknown error, please try again later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="284"/>
        <source>Phone can not same</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="293"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="321"/>
        <source>finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="303"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="332"/>
        <source>Phone number already in used!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePinIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepininteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepininteldialog.ui" line="74"/>
        <source>Change Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeProjectionName</name>
    <message>
        <location filename="../../../plugins/system/projection/changeprojectionname.ui" line="26"/>
        <source>Change Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/changeprojectionname.ui" line="96"/>
        <source>Changename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/changeprojectionname.ui" line="132"/>
        <source>ChangeProjectionname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/changeprojectionname.ui" line="194"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/changeprojectionname.ui" line="213"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/changeprojectionname.cpp" line="24"/>
        <source>Name is too long, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePwdDialog</name>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="130"/>
        <source>Change Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="317"/>
        <source>Pwd type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="395"/>
        <source>Cur pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="440"/>
        <source>New pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="485"/>
        <source>New pwd sure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="605"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.ui" line="627"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="64"/>
        <source>Change pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="172"/>
        <source>General Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="178"/>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="389"/>
        <source>Current Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="179"/>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="390"/>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="398"/>
        <source>New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="180"/>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="391"/>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="399"/>
        <source>New Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="188"/>
        <source>Pwd input error, re-enter!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="245"/>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="365"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="327"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/changepwddialog.cpp" line="329"/>
        <source>Same with old pwd</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePwdIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.ui" line="119"/>
        <source>Change Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.ui" line="603"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.ui" line="643"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="186"/>
        <source>General Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="198"/>
        <source>Old Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="199"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="575"/>
        <source>New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="200"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="576"/>
        <source>New Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="332"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="341"/>
        <source>Please set different pwd!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="349"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="560"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="414"/>
        <source>Old pwd is wrong!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="416"/>
        <source>New pwd is too similar with old pwd!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="421"/>
        <source>Check old pwd failed because of unknown reason!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="537"/>
        <source>Password length needs to more than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="539"/>
        <source>Password length needs to less than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="547"/>
        <source>Password cannot be made up entirely by Numbers!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeTypeIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="108"/>
        <source>Change Account Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="409"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="422"/>
        <source>Standard users can use most software, but cannot install software and change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="543"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="556"/>
        <source>Administrators can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="579"/>
        <source>Make sure that there is at least one administrator on the computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="619"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="654"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserLogo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="139"/>
        <source>System Logos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="148"/>
        <source>Local Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="157"/>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="291"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="159"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="286"/>
        <source>select custom face file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="287"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="288"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="289"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="290"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="306"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="307"/>
        <source>The avatar is larger than 1M, please choose again</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserNickname</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="69"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="86"/>
        <source>NickName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="90"/>
        <source>Name already in use, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="121"/>
        <source>ComputerName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="145"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="148"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserPwd</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="119"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="123"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="398"/>
        <source>Current Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="136"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="140"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="399"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="407"/>
        <source>New Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="153"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="157"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="400"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="408"/>
        <source>Sure Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="195"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="198"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="242"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="472"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="292"/>
        <source>Authentication failed, input authtok again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="433"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserType</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="25"/>
        <source>UserType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="70"/>
        <source>Ensure that must have admin on system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="80"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="82"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="84"/>
        <source>Users can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="86"/>
        <source>Users cannot change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="137"/>
        <source>Note: Effective After Logout!!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="148"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="151"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeValidIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="180"/>
        <source>Password Validity Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="312"/>
        <source>Current passwd validity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="394"/>
        <source>Adjust date to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="493"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="500"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangtimeDialog</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="161"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="162"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="163"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="164"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="86"/>
        <source>选择自定义颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="236"/>
        <source>HEX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="250"/>
        <source>RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="411"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="430"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.cpp" line="95"/>
        <source>Custom color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="50"/>
        <source>Add New Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="77"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="124"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="172"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="266"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="288"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.cpp" line="206"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateGroupIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="115"/>
        <source>Add New Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="144"/>
        <source>Group Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="182"/>
        <source>Group Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="234"/>
        <source>Group Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="344"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="363"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateUserIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="117"/>
        <source>Add New Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="458"/>
        <source>Account Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="550"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="563"/>
        <source>Standard users can use most software, but cannot install the software and 
change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="666"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="679"/>
        <source>Administrators can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="728"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="760"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="150"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="151"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="152"/>
        <source>Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="307"/>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="430"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="417"/>
        <source>Password length needs to more than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="419"/>
        <source>Password length needs to less than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="526"/>
        <source>The user name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="528"/>
        <source>The first character must be lowercase letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="531"/>
        <source>User name can not contain capital letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="545"/>
        <source>The user name is already in use, please use a different one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="550"/>
        <source>User name length need to less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="552"/>
        <source>The user name can only be composed of letters, numbers and underline!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="557"/>
        <source>The username is configured, please change the username</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateUserNew</name>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="26"/>
        <source>CreateUserNew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="47"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="50"/>
        <source>NickName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="53"/>
        <source>Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="56"/>
        <source>SurePwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="113"/>
        <source>Select Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="122"/>
        <source>Administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="125"/>
        <source>Users can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="127"/>
        <source>Standard User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="130"/>
        <source>Users cannot change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="202"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="204"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="249"/>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="505"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="373"/>
        <source>The nick name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="377"/>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="443"/>
        <source>Nickname cannot same with username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="399"/>
        <source>The user name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="401"/>
        <source>Must be begin with lower letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="404"/>
        <source>Can not contain capital letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="426"/>
        <source>Name already in use, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="428"/>
        <source>Name corresponds to group already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="433"/>
        <source>Name length must less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="435"/>
        <source>Can only contain letters,digits,underline!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="439"/>
        <source>Username&apos;s folder exists, change another one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="475"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomLineEdit</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/customlineedit.cpp" line="28"/>
        <source>New Shortcut...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateTime</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="26"/>
        <source>DateTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="62"/>
        <source>current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="318"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="242"/>
        <source>Change timezone</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Change time zone</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="441"/>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="602"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="472"/>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="479"/>
        <source>RadioButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="694"/>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="726"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="934"/>
        <source>titleLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="85"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="162"/>
        <source>Other Timezone</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Other Timezone</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="176"/>
        <source>24-hour clock</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/24-hour clock</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="178"/>
        <source>Sync Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Sync time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="198"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="255"/>
        <source>Manual Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Manual Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="253"/>
        <source>Auto Sync Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Auto Sync Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="577"/>
        <source>Add Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="399"/>
        <source>Sync Server</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Sync Server</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="401"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="403"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="413"/>
        <source>Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="418"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="419"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="566"/>
        <source>change time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="579"/>
        <source>Change Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="772"/>
        <source>  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="773"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="782"/>
        <source>Sync from network failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultApp</name>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="37"/>
        <source>Default App</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="61"/>
        <source>No program available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="305"/>
        <source>Browser</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Browser</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="307"/>
        <source>Mail</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Mail</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="309"/>
        <source>Image Viewer</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Image Viewer</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="311"/>
        <source>Audio Player</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Audio Player</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="313"/>
        <source>Video Player</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Video Player</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="315"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Text Editor</extra-contents_path>
    </message>
</context>
<context>
    <name>DefaultAppWindow</name>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="303"/>
        <source>Select Default Application</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineGroupItem</name>
    <message>
        <location filename="../../../plugins/account/userinfo/definegroupitem.cpp" line="53"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/definegroupitem.cpp" line="62"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineGroupItemIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/definegroupitemintel.cpp" line="53"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/definegroupitemintel.cpp" line="62"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineShortcutItem</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/defineshortcutitem.cpp" line="58"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="87"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="81"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="53"/>
        <source>Delete user group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="68"/>
        <source>Are you sure to delete the group:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="73"/>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="74"/>
        <source>which will make some file components in the file system invalid!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelGroupIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="38"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="82"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="104"/>
        <source>RemoveFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="145"/>
        <source>Remind</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelUserIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.ui" line="90"/>
        <source>   Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.ui" line="216"/>
        <source>Define</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.ui" line="241"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.cpp" line="54"/>
        <source>Delete the user, belonging to the user&apos;s desktop documents, favorites, music, pictures and video folder will be deleted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteUserExists</name>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="59"/>
        <source>Delete user &apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="60"/>
        <source>&apos;? And:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="85"/>
        <source>Keep user&apos;s home folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="87"/>
        <source>Delete whole data belong user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="119"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="121"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceInfoItem</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="27"/>
        <source>Connecting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="28"/>
        <source>Disconnecting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="29"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="30"/>
        <source>Ununited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="31"/>
        <source>Connect fail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="96"/>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="293"/>
        <source>Send files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="102"/>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="295"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="104"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="105"/>
        <source>remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="112"/>
        <source>Sure to remove,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="114"/>
        <source>After removal, the next connection requires matching PIN code!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceType</name>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricdeviceinfo.cpp" line="40"/>
        <source>FingerPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricdeviceinfo.cpp" line="42"/>
        <source>FingerVein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricdeviceinfo.cpp" line="44"/>
        <source>Iris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricdeviceinfo.cpp" line="46"/>
        <source>Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/biometrics/biometricdeviceinfo.cpp" line="48"/>
        <source>VoicePrint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DigitalAuthIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="52"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="287"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="312"/>
        <source>Enter Old Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="76"/>
        <source>Forget Password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="97"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="152"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="223"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="253"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="263"/>
        <source>Input New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="142"/>
        <source>Input Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="230"/>
        <source>The password input is error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="244"/>
        <source>Confirm New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="250"/>
        <source>The password input is inconsistent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="260"/>
        <source>New password can not be consistent of old password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="284"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="309"/>
        <source>Password Change Failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DigitalPhoneIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalphoneinteldialog.cpp" line="52"/>
        <source>Please Enter Edu OS Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalphoneinteldialog.cpp" line="163"/>
        <source>The password input is error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayPerformanceDialog</name>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="214"/>
        <source>Display Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="297"/>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="376"/>
        <source>Applicable to machine with discrete graphics, which can accelerate the rendering of 3D graphics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="392"/>
        <source>(Note: not support connect graphical with xmanager on windows.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="462"/>
        <source>Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="538"/>
        <source>Applicable to machine with integrated graphics,  there is no 3D graphics acceleration. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="554"/>
        <source>(Note: need connect graphical with xmanager on windows, use this option.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="624"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="700"/>
        <source>Auto select according to environment, delay the login time (about 0.5 sec).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="721"/>
        <source>Threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="744"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="757"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="772"/>
        <source>(Note: select this option to use 3D graphics acceleration and xmanager.)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplaySet</name>
    <message>
        <location filename="../../../plugins/system/display/display.cpp" line="33"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayWindow</name>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="32"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="142"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="188"/>
        <source>set as home screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="241"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="308"/>
        <source>open monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="362"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="404"/>
        <source>unify output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="546"/>
        <source>follow the sunrise and sunset(17:55-05:04)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="610"/>
        <source>custom time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="674"/>
        <source>opening time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="757"/>
        <source>closing time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="852"/>
        <source>color temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="859"/>
        <source>warm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="882"/>
        <source>cold</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="275"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="297"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="50"/>
        <source>Edit User Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="77"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="124"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="175"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="223"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="223"/>
        <source>Invalid Id!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="226"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="276"/>
        <source>Edit user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExperiencePlan</name>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="79"/>
        <source>User Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="130"/>
        <source>Join in user Experience plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="172"/>
        <source>User experience plan terms, see</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="179"/>
        <source>《User Experience plan》</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.cpp" line="33"/>
        <source>Experienceplan</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fonts</name>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="47"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="64"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="119"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="139"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Font size</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="169"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="141"/>
        <source>Fonts select</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Fonts select</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="238"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="143"/>
        <source>Mono font</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Mono font</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="302"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameItem</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="117"/>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="132"/>
        <source>Sync failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="120"/>
        <source>Change configuration file failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="123"/>
        <source>Configuration file not exist,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="126"/>
        <source>Cloud verifyed file download failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="129"/>
        <source>OSS access failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Gesture</name>
    <message>
        <location filename="../../../plugins/devices/gesture/gesture.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/gesture/gesture.cpp" line="6"/>
        <location filename="../../../plugins/devices/gesture/gesture.cpp" line="71"/>
        <source>Gesture</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryUpdateListWig</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/historyupdatelistwig.cpp" line="98"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/historyupdatelistwig.cpp" line="100"/>
        <source>Failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HostNameDialog</name>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="11"/>
        <source>Set HostName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="39"/>
        <source>HostName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="60"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="64"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputPwdDialog</name>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="29"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="46"/>
        <source>Set Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="78"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="82"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="122"/>
        <source>less than or equal to 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="98"/>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="118"/>
        <source>Password can not be blank</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ItemList</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>ScreenSaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Quick Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Wallpaper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>TouchPad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>KeyBoard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>ShortCut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>Themes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Date/Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Default Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Peony</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Weather</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Itemwidget</name>
    <message>
        <location filename="../../../plugins/devices/gesture/itemwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/gesture/itemwidget.ui" line="80"/>
        <location filename="../../../plugins/devices/gesture/itemwidget.ui" line="195"/>
        <location filename="../../../plugins/devices/gesture/itemwidget.ui" line="230"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/gesture/itemwidget.ui" line="112"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbPreviewFrame</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/kbpreviewframe.cpp" line="321"/>
        <source>No preview found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/kbpreviewframe.cpp" line="325"/>
        <source>Unable to open Preview !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbdLayoutManager</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="68"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="144"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="222"/>
        <source>Variant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="270"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="61"/>
        <source>Add Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="237"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="291"/>
        <source>Keyboard Preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyValueConverter</name>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="46"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="49"/>
        <source>Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="55"/>
        <source>Personalized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="52"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="58"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="61"/>
        <source>Datetime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="64"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="67"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="70"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="73"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardControl</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="24"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardMain</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="39"/>
        <source>Key board settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="50"/>
        <source>Input settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Input settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="88"/>
        <source>Key repeat</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Key repeat</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="110"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Delay</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="112"/>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="114"/>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="140"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="142"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="144"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="170"/>
        <source>Input test</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Input test</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="191"/>
        <source>Key tips</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Key tips</extra-contents_path>
    </message>
</context>
<context>
    <name>KeyboardPainter</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="31"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="67"/>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="69"/>
        <source>Keyboard layout levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="67"/>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="69"/>
        <source>Level %1, %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LayoutManager</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="121"/>
        <source>Manager Keyboard Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="234"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="250"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="293"/>
        <source>Variant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="351"/>
        <source>Layout installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="399"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="431"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="450"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoginDialog</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="40"/>
        <source>Forget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="43"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="44"/>
        <source>User Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="45"/>
        <source>Quick Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="104"/>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="356"/>
        <source>Your code here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="177"/>
        <source>Your phone number here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="96"/>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="221"/>
        <source>Your account/phone/email here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="235"/>
        <source>Your password here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MCodeWidget</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/mcodewidget.cpp" line="33"/>
        <source>SongTi</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="32"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="276"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="300"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="307"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="647"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="862"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="873"/>
        <source>Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="33"/>
        <source>Sign up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="55"/>
        <source>Login in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="365"/>
        <source>Error code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="365"/>
        <source>!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="367"/>
        <source>Internal error occurred!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="368"/>
        <source>Failed to sign up!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="369"/>
        <source>Failed attempt to return value!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="370"/>
        <source>Check your connection!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="371"/>
        <source>Failed to get by phone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="372"/>
        <source>Failed to get by user!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="373"/>
        <source>Failed to reset password!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="374"/>
        <source>Timeout!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="375"/>
        <source>Phone binding falied!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="376"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="397"/>
        <source>Please check your information!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="377"/>
        <source>Please check your account!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="378"/>
        <source>Failed due to server error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="379"/>
        <source>User and passsword can&apos;t be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="380"/>
        <source>User existing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="381"/>
        <source>User doesn&apos;t exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="382"/>
        <source>Network can not reach!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="383"/>
        <source>Phone can&apos;t be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="384"/>
        <source>Account or password error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="385"/>
        <source>Phone number already in used!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="386"/>
        <source>Please check your format!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="387"/>
        <source>Your are reach the limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="388"/>
        <source>Please check your phone number!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="389"/>
        <source>Please check your code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="390"/>
        <source>Account doesn&apos;t exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="391"/>
        <source>User has bound the phone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="392"/>
        <source>Sending code error occurred!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="393"/>
        <source>Phone code is expired!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="394"/>
        <source>Phone code error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="395"/>
        <source>Code can not be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="396"/>
        <source>MCode can not be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="479"/>
        <source>Your code is wrong!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="493"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="592"/>
        <source>Please check your phone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="837"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.h" line="55"/>
        <source>Sign in Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="622"/>
        <source>Resend ( %1 )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="627"/>
        <source>Get</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWidget</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="453"/>
        <source>Your account：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="474"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1158"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1175"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="843"/>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="486"/>
        <source>Sign in</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/networkaccount/Sign in</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="411"/>
        <source>Waiting for initialization...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="231"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="316"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="602"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="622"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="679"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="944"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="963"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1243"/>
        <source>Network can not reach!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="385"/>
        <source>Logout failed,please check your connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="540"/>
        <source>Waitting for sync!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1132"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1147"/>
        <source>Stop sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="847"/>
        <source>Sync your settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="850"/>
        <source>Your account:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="851"/>
        <source>Auto sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="834"/>
        <source>Synchronize your personalized settings and data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="712"/>
        <source>The Cloud Account Service version is out of date!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="909"/>
        <source>KylinID open error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="983"/>
        <source>Unauthorized device or OSS falied.
Please retry or relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="987"/>
        <source>Authorization failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1230"/>
        <source>Kylin Cloud Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="409"/>
        <source>The latest time sync is: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="639"/>
        <source>This operation may cover your settings!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1233"/>
        <source>Cloud ID desktop message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="103"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="428"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="438"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1103"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.h" line="109"/>
        <source>Disconnected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../mainwindow.cpp" line="346"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="366"/>
        <location filename="../../mainwindow.cpp" line="575"/>
        <location filename="../../mainwindow.cpp" line="820"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="375"/>
        <source>Main menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="376"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="377"/>
        <source>Maximize/Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="378"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="441"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="443"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="445"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="933"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="933"/>
        <source>This function has been controlled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBox</name>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="97"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="138"/>
        <source>It takes effect after logging off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="209"/>
        <source>Logout Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="228"/>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="30"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="29"/>
        <source>Reboot Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="31"/>
        <source>This cleanup and restore need to be done after the system restarts, whether to restart and restore immediately?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="34"/>
        <source>System Backup Tips</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBoxDialog</name>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="68"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="152"/>
        <source>You do not have administrator rights!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="162"/>
        <source> Factory Settings cannot be restored!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="247"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBoxPower</name>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="53"/>
        <source>System Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="62"/>
        <source>The battery is low,please connect the power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="64"/>
        <source>Keep the power connection, or the power is more than 25%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="68"/>
        <source>Remind in 30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="80"/>
        <source>Got it</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBoxPowerIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/messageboxpowerintel.cpp" line="48"/>
        <source>Nothing has been entered, re-enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/messageboxpowerintel.cpp" line="59"/>
        <source>Remind in 30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/messageboxpowerintel.cpp" line="71"/>
        <source>Got it</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MobileHotspot</name>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspot.cpp" line="28"/>
        <source>MobileHotspot</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MobileHotspotWidget</name>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="26"/>
        <source>ukui control center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="29"/>
        <source>ukui control center desktop message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="93"/>
        <source>start to close hotspot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="102"/>
        <source>hotpots name or device is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="106"/>
        <source>can not  create hotspot with password length less than eight!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="109"/>
        <source>start to open hotspot </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="142"/>
        <source>Hotspot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="333"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="353"/>
        <source>Wi-Fi Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="373"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="411"/>
        <source>Frequency band</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="435"/>
        <source>Net card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="196"/>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="490"/>
        <source>hotspot already close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="506"/>
        <location filename="../../../plugins/network/mobilehotspot/mobilehotspotwidget.cpp" line="514"/>
        <source>hotspot already open</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MouseControl</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="24"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MouseUI</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="93"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="99"/>
        <source>Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="106"/>
        <source>Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="165"/>
        <source>Dominant hand</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Dominant hand</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="167"/>
        <source>Left hand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="168"/>
        <source>Right hand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="193"/>
        <source>Wheel speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Wheel speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="195"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="257"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="390"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="201"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="264"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="397"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="223"/>
        <source>Double-click interval time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Double-click interval time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="225"/>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="232"/>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="255"/>
        <source>Pointer speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Pointer speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="287"/>
        <source>Mouse acceleration</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Mouse acceleration</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="308"/>
        <source>Show pointer position when pressing ctrl</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Show pointer position when pressing ctrl</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="330"/>
        <source>Pointer size</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Pointer size</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="332"/>
        <source>Small(recommend)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="333"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="334"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="366"/>
        <source>Blinking cursor in text area</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Blinking cursor in text area</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="388"/>
        <source>Cursor speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Cursor speed</extra-contents_path>
    </message>
</context>
<context>
    <name>MyLabel</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="21"/>
        <source>double-click to test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetConnect</name>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="47"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="119"/>
        <source>Wired Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="109"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="121"/>
        <source>open</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/netconnect/open</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="208"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="118"/>
        <source>Advanced settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/netconnect/Advanced settings&quot;</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="53"/>
        <source>WiredConnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="435"/>
        <source>card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="370"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="748"/>
        <source>connected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Notice</name>
    <message>
        <location filename="../../../plugins/system/notice/notice.cpp" line="187"/>
        <source>Notice Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/notice/notice.cpp" line="189"/>
        <source>Get notifications from the app</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/notice/Get notifications from the app</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/notice/notice.cpp" line="39"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NumbersButtonIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/numbersbuttonintel.cpp" line="47"/>
        <source>clean</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputConfig</name>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="64"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/resolution</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="93"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/orientation</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="110"/>
        <source>arrow-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="111"/>
        <source>90° arrow-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="113"/>
        <source>arrow-down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="125"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/frequency</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="112"/>
        <source>90° arrow-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="142"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="165"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/screen zoom</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="282"/>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="288"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhoneAuthIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="42"/>
        <source>Wechat Auth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="44"/>
        <source>Phone Auth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="71"/>
        <source>Phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="75"/>
        <source>SMS verification code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="105"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="331"/>
        <source>GetCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="115"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="116"/>
        <source>Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="204"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="224"/>
        <source>commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="260"/>
        <source>Mobile number acquisition failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="292"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="323"/>
        <source>Recapture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="315"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="393"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="563"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="681"/>
        <source>Network connection failure, please check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="380"/>
        <source>Phone is lock,try again in an hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="386"/>
        <source>Phone code is wrong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="399"/>
        <source>Current login expired,using wechat code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="405"/>
        <source>Unknown error, please try again later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="662"/>
        <source>Please use the correct wechat scan code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Power</name>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="59"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <location filename="../../../plugins/system/power/power.cpp" line="729"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="542"/>
        <location filename="../../../plugins/system/power/power.cpp" line="543"/>
        <source>Require password when sleep/hibernation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="546"/>
        <location filename="../../../plugins/system/power/power.cpp" line="547"/>
        <source>Password required when waking up the screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="550"/>
        <source>Press the power button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="554"/>
        <location filename="../../../plugins/system/power/power.cpp" line="555"/>
        <source>Time to close display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="558"/>
        <location filename="../../../plugins/system/power/power.cpp" line="559"/>
        <source>Time to sleep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="562"/>
        <location filename="../../../plugins/system/power/power.cpp" line="563"/>
        <source>Notebook cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="566"/>
        <location filename="../../../plugins/system/power/power.cpp" line="567"/>
        <source>Balance (suggest)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="570"/>
        <location filename="../../../plugins/system/power/power.cpp" line="571"/>
        <source>Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="574"/>
        <location filename="../../../plugins/system/power/power.cpp" line="575"/>
        <source>Autobalance energy and performance with available hardware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="578"/>
        <location filename="../../../plugins/system/power/power.cpp" line="579"/>
        <source>Users develop personalized power plans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="582"/>
        <location filename="../../../plugins/system/power/power.cpp" line="583"/>
        <location filename="../../../plugins/system/power/power.cpp" line="587"/>
        <source>Using power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="586"/>
        <source>Using battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="590"/>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <source> Time to darken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="594"/>
        <location filename="../../../plugins/system/power/power.cpp" line="595"/>
        <source>Battery level is lower than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="598"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="600"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>Low battery notification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="604"/>
        <source>Automatically run saving mode when low battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="605"/>
        <source>Automatically run saving mode when the low battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="608"/>
        <location filename="../../../plugins/system/power/power.cpp" line="609"/>
        <source>Automatically run saving mode when using battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="612"/>
        <location filename="../../../plugins/system/power/power.cpp" line="613"/>
        <source>Display remaining charging time and usage time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="670"/>
        <source>General</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/power/General</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="672"/>
        <source>Select Powerplan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/power/Select Powerplan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="674"/>
        <source>Battery saving plan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/power/Battery saving plan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="737"/>
        <source>nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="737"/>
        <source>blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <location filename="../../../plugins/system/power/power.cpp" line="737"/>
        <source>suspend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="686"/>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <location filename="../../../plugins/system/power/power.cpp" line="743"/>
        <source>hibernate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <source>interactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="729"/>
        <source>5min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <location filename="../../../plugins/system/power/power.cpp" line="729"/>
        <source>10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>15min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>30min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>1h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>2h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>3h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="720"/>
        <location filename="../../../plugins/system/power/power.cpp" line="724"/>
        <source>Balance Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="720"/>
        <location filename="../../../plugins/system/power/power.cpp" line="724"/>
        <source>Save Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="729"/>
        <source>1min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="729"/>
        <source>20min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <location filename="../../../plugins/system/power/power.cpp" line="737"/>
        <source>shutdown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Printer</name>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="32"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="111"/>
        <source>Printers And Scanners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="176"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/printer/Add</extra-contents_path>
    </message>
</context>
<context>
    <name>Projection</name>
    <message>
        <location filename="../../../plugins/system/projection/projection.ui" line="53"/>
        <location filename="../../../plugins/system/projection/projection.cpp" line="49"/>
        <source>Projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.ui" line="230"/>
        <source>msg info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.ui" line="246"/>
        <source>label for set size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.ui" line="373"/>
        <source>msg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="66"/>
        <source>Open Projection</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/projection/Open Projection</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="255"/>
        <source>Service exception,please restart the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="261"/>
        <source>Network card is not detected or the driver is not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="271"/>
        <source>Please keep WLAN on;
Wireless-network functions will be invalid when the screen projection on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="273"/>
        <source>Please keep WLAN on;
Wireless will be temporarily disconnected when the screen projection on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="280"/>
        <source>After opening the switch button,open the projection screen in the mobile phone drop-down menu,follow the prompts.See the user manual for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="285"/>
        <source>WLAN is off, please turn on WLAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="291"/>
        <source>Wireless network card is busy. Please try again later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="340"/>
        <source>projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="343"/>
        <source>Projection is </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="343"/>
        <source>on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="343"/>
        <source>off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="344"/>
        <source>Please enable or refresh the scan at the projection device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="344"/>
        <source>You need to turn on the projection again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="355"/>
        <source>Failed to execute. Please reopen the page later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/projection/projection.cpp" line="377"/>
        <source>Add Bluetooths</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Proxy</name>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="475"/>
        <source>Auto Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Auto Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="477"/>
        <source>Auto url</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Auto url</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="479"/>
        <source>Manual Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Manual Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="481"/>
        <source>Http Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Http Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="488"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="489"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="490"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="491"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="473"/>
        <source>System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="483"/>
        <source>Https Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Https Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="485"/>
        <source>Ftp Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Ftp Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="487"/>
        <source>Socks Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Socks Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="492"/>
        <source>List of ignored hosts. more than one entry, please separate with english semicolon(;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="493"/>
        <source>Enable Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="494"/>
        <source>User Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="495"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="498"/>
        <source>Apt Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Apt Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="499"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="500"/>
        <source>Server Address : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="501"/>
        <source>Port : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="502"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="834"/>
        <source>The system needs to be restarted to set the Apt proxy, whether to reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="835"/>
        <source>Reboot Later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="836"/>
        <source>Reboot Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="45"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="186"/>
        <source>Customize Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="453"/>
        <source>Edit Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="741"/>
        <source>blue-crystal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="743"/>
        <source>dark-sense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="745"/>
        <source>DMZ-Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="747"/>
        <source>DMZ-White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="769"/>
        <source>basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="771"/>
        <source>classical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="773"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="781"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="775"/>
        <source>fashion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="777"/>
        <source>hp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="779"/>
        <source>ukui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="173"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="167"/>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="204"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="206"/>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="224"/>
        <source>Jan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="225"/>
        <source>Feb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="226"/>
        <source>Mar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="227"/>
        <source>Apr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="228"/>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="229"/>
        <source>Jun</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="230"/>
        <source>Jul</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="231"/>
        <source>Aug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="232"/>
        <source>Sep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="233"/>
        <source>Oct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="234"/>
        <source>Nov</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="235"/>
        <source>Dec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="256"/>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>January</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>February</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>March</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>April</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>June</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>July</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>August</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>September</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>October</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>Novermber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>December</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="966"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="322"/>
        <source>min length %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="976"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="332"/>
        <source>min digit num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="985"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="341"/>
        <source>min upper num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="994"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="350"/>
        <source>min lower num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1003"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="359"/>
        <source>min other num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1013"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="369"/>
        <source>min char class %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1022"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="378"/>
        <source>max repeat %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1031"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="387"/>
        <source>max class repeat %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1040"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="396"/>
        <source>max sequence %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="81"/>
        <source>ukui-control-center is already running!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="90"/>
        <source>ukui-control-center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1500"/>
        <source>pa_context_subscribe() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1516"/>
        <source>pa_context_client_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1523"/>
        <source>pa_context_get_card_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1530"/>
        <source>pa_context_get_sink_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1537"/>
        <source>pa_context_get_source_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1301"/>
        <source>Failed to initialize stream_restore extension: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1544"/>
        <source>pa_context_get_sink_input_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1551"/>
        <source>pa_context_get_source_output_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1567"/>
        <source>Connection failed, attempting reconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1318"/>
        <source>pa_ext_stream_restore_read() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="217"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1433"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1509"/>
        <source>pa_context_get_server_info() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1191"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1663"/>
        <source>Sink input callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1211"/>
        <source>Source output callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1251"/>
        <source>Client callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1267"/>
        <source>Server info callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1335"/>
        <source>Failed to initialize device manager extension: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1354"/>
        <source>pa_ext_device_manager_read() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1371"/>
        <source>pa_context_get_sink_info_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1384"/>
        <source>pa_context_get_source_info_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1397"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1410"/>
        <source>pa_context_get_sink_input_info() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1423"/>
        <source>pa_context_get_client_info() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1460"/>
        <source>pa_context_get_card_info_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1587"/>
        <source>Ukui Media Volume Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1132"/>
        <source>Card callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1150"/>
        <source>Sink callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1170"/>
        <source>Source callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="46"/>
        <source>Go to monitor settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="47"/>
        <source>Go to defaultapp settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="48"/>
        <source>Go to power settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="49"/>
        <source>Go to autoboot settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="51"/>
        <source>Go to printer settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="52"/>
        <source>Go to projection settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="53"/>
        <source>Go to mouse settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="54"/>
        <source>Go to touchpad settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="57"/>
        <source>Go to keyboard settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="58"/>
        <source>Go to shortcut settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="59"/>
        <source>Go to audio settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="60"/>
        <source>Go to bluetooth settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="62"/>
        <source>Go to background settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="63"/>
        <source>Go to theme settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="64"/>
        <source>Go to screenlock settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="65"/>
        <source>Go to screensaver settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="66"/>
        <source>Go to fonts settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="67"/>
        <source>Go to desktop settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="69"/>
        <source>Go to wiredconnect settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="70"/>
        <source>Go to wlanconnect settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="71"/>
        <source>Go to vpn settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="72"/>
        <source>Go to proxy settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="73"/>
        <source>Go to mobilehotspot settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="75"/>
        <source>Go to userinfo settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="76"/>
        <source>Go to cloudaccount settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="78"/>
        <source>Go to datetime settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="79"/>
        <source>Go to area settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="81"/>
        <source>Go to update settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="82"/>
        <source>Go to backup settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="83"/>
        <source>Go to upgrade settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="85"/>
        <source>Go to notice settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="86"/>
        <source>Go to about settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="87"/>
        <source>Go to search settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/backup.cpp" line="135"/>
        <source>system upgrade new backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/backup.cpp" line="136"/>
        <source>system upgrade increment backup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screenlock</name>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="26"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="46"/>
        <source>Screenlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="77"/>
        <source>Screenlock Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="208"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="117"/>
        <source>Show picture of screenlock on screenlogin</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Show picture of screenlock on screenlogin</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="278"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="119"/>
        <source>Lock screen when screensaver boot</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Lock screen when screensaver boot</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="361"/>
        <source>Lock screen delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="445"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="121"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Browse</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="452"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="123"/>
        <source>Online Picture</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Online Picture</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="484"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="132"/>
        <source>Reset To Default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Reset To Default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>5m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>10m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>30m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>45m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>1m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="150"/>
        <source>1h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="150"/>
        <source>1.5h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="150"/>
        <source>3h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="150"/>
        <source>2h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="150"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="448"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="448"/>
        <source>allFiles(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="490"/>
        <source>select custom wallpaper file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="491"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="492"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="493"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="494"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="495"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screensaver</name>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="59"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="96"/>
        <source>Screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="201"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="193"/>
        <source>Idle time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screensaver/Idle time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="475"/>
        <source>Lock screen when activating screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="297"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="191"/>
        <source>Screensaver program</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screensaver/Screensaver program</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="179"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="220"/>
        <source>UKUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="221"/>
        <source>Blank_Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="232"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="247"/>
        <source>15min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="247"/>
        <source>1hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="248"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="651"/>
        <source>Screensaver source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="657"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="707"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="665"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp *.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="706"/>
        <source>select custom screensaver dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="708"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="709"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="710"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="711"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="744"/>
        <source>Switching time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="748"/>
        <source>1min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="846"/>
        <source>Text(up to 30 characters):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="247"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="749"/>
        <source>5min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="247"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="750"/>
        <source>10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="247"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="751"/>
        <source>30min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="796"/>
        <source>Ordinal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="797"/>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="805"/>
        <source>Random switching</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="880"/>
        <source>Show rest time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="899"/>
        <source>Text position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="907"/>
        <source>Centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="908"/>
        <source>Randow(Bubble text)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Search</name>
    <message>
        <location filename="../../../plugins/messages-task/search/search.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="7"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="121"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="189"/>
        <source>Block Folders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="192"/>
        <source>Following folders will not be searched. You can set it by adding and removing folders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="234"/>
        <source>Choose folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="173"/>
        <source>Default web searching engine</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/search/Default web searching engine</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="147"/>
        <source>Create index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="148"/>
        <source>Creating index can help you getting results quickly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="178"/>
        <source>baidu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="179"/>
        <source>sougou</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="180"/>
        <source>360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="377"/>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="432"/>
        <source>Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="434"/>
        <source>select blocked folder</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/search/select blocked folder</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="435"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="436"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="437"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="438"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="439"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="455"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="459"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="463"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="467"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="455"/>
        <source>Add blocked folder failed, choosen path is empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="459"/>
        <source>Add blocked folder failed, it is not in home path!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="463"/>
        <source>Add blocked folder failed, its parent dir is exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="467"/>
        <source>Add blocked folder failed, it has been already blocked!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityCenter</name>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/securitycenter.cpp" line="15"/>
        <source>Security Center</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShareMain</name>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="57"/>
        <source>Remote Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="66"/>
        <source>Allow others to view your desktop</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vino/Allow others to view your desktop</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="81"/>
        <source>Allow connection to control screen</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vino/Allow connection to control screen</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="96"/>
        <source>You must confirm every visit for this machine</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vino/You must confirm every visit for this machine</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="111"/>
        <source>Require user to enter this password: </source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vino/Require user to enter this password:</extra-contents_path>
    </message>
</context>
<context>
    <name>Shortcut</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.ui" line="50"/>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="163"/>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="177"/>
        <source>System Shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/shortcut/System Shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.ui" line="103"/>
        <source>Custom Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="165"/>
        <source>Customize Shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/shortcut/Customize Shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="438"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="437"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="79"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="160"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Add</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="712"/>
        <source> or </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyncDialog</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="34"/>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="35"/>
        <source>Do not</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="60"/>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="101"/>
        <source>Last sync at %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="100"/>
        <source>Sync now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Wallpaper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>ScreenSaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Quick Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>Themes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>TouchPad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>KeyBoard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>ShortCut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Date/Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Default Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Peony</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Weather</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabWid</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="43"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="102"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="114"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="119"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="156"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="388"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="417"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="682"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="789"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="927"/>
        <source>Check Update</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/upgrade/Check Update</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="46"/>
        <source>initializing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="109"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="195"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="330"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="710"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="815"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="897"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="964"/>
        <source>UpdateAll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="132"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="242"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="265"/>
        <source>Downloading and installing updates...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="158"/>
        <source>Failed to connect to software warehouse!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="174"/>
        <source>Update now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="175"/>
        <source>Cancel update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="182"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="321"/>
        <source>Being updated...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="194"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="713"/>
        <source>Updatable app detected on your system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="204"/>
        <source>The backup restore partition could not be found. The system will not be backed up in this update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="208"/>
        <source>Kylin backup restore tool is doing other operations, please update later.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="211"/>
        <source>The source manager configuration file is abnormal, the system temporarily unable to update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="214"/>
        <source>Backup already, no need to backup again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="222"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="994"/>
        <source>Start backup,getting progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="228"/>
        <source>Kylin backup restore tool does not exist, this update will not backup the system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="243"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="839"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="276"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="684"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="931"/>
        <source>Your system is the latest!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="287"/>
        <source>Backup complete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="290"/>
        <source>System is backing up...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="302"/>
        <source>Backup interrupted, stop updating!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="306"/>
        <source>Backup finished!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="310"/>
        <source>Kylin backup restore tool exception:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="310"/>
        <source>There will be no backup in this update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="381"/>
        <source>Getting update list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="385"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="419"/>
        <source>Software source update failed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="438"/>
        <source>Update software source :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="465"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="489"/>
        <source>View history</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/upgrade/View history</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="534"/>
        <source>Update Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="546"/>
        <source>Allowed to renewable notice</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/upgrade/Allowed to renewable notice</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="556"/>
        <source>Backup current system before updates all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="569"/>
        <source>Automatically download and install updates</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/upgrade/Automatically download and install updates</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="571"/>
        <source>After it is turned on, the system will automatically download and install updates when there is an available network and available backup and restore partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="641"/>
        <source>Ready to install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="702"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="750"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="918"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="951"/>
        <source>Last refresh:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="752"/>
        <source>Last Checked:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="784"/>
        <source>trying to reconnect </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="784"/>
        <source> times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="803"/>
        <source>Updating the software source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="819"/>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="822"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="833"/>
        <source>Please back up the system before all updates to avoid unnecessary losses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="834"/>
        <source>Prompt information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="837"/>
        <source>Only Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="838"/>
        <source>Back And Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="938"/>
        <source>Part of the update failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="975"/>
        <source>An important update is in progress, please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1001"/>
        <source>Failed to write configuration file, this update will not back up the system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1005"/>
        <source>Insufficient backup space, this update will not backup your system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1009"/>
        <source>Kylin backup restore tool could not find the UUID, this update will not backup the system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1012"/>
        <source>The backup restore partition is abnormal. You may not have a backup restore partition.For more details,see /var/log/backup.log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1019"/>
        <source>Calculating Capacity...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Theme</name>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="76"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="170"/>
        <source>Theme Mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Theme Mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="361"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="172"/>
        <source>Icon theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Icon theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="437"/>
        <source>Control theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="512"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="174"/>
        <source>Cursor theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Cursor theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="588"/>
        <source>Effect setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="667"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="176"/>
        <source>Performance mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Performance mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="751"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="178"/>
        <source>Transparency</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Transparency</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="866"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="113"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="251"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="252"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="253"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeBtn</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="79"/>
        <source>Tomorrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="81"/>
        <source>Yesterday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="83"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="101"/>
        <source>%1 hours earlier than local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="103"/>
        <source>%1 hours later than local</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeZoneChooser</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="34"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="35"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="45"/>
        <source>Change time zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="69"/>
        <source>Search Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="98"/>
        <source>Change Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="124"/>
        <source>To select a time zone, please click where near you on the map and select a city from the nearest city</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TouchScreen</name>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="14"/>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="32"/>
        <location filename="../../../plugins/system/touchscreen/touchscreen.cpp" line="12"/>
        <source>TouchScreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="69"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="134"/>
        <source>touch id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="236"/>
        <source>map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="258"/>
        <source>calibration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="285"/>
        <source>No touch screen found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="202"/>
        <source>input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="209"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Touchpad</name>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="31"/>
        <source>Touchpad</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TouchpadUI</name>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="39"/>
        <source>Touchpad Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="43"/>
        <source>No touchpad found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="58"/>
        <source>Disable touchpad when using the mouse</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Disable touchpad when using the mouse</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="75"/>
        <source>Cursor Speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Cursor Speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="77"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="78"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="102"/>
        <source>Disable touchpad when typing</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Disable touchpad when typing</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="120"/>
        <source>Touch and click on the touchpad</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Touch and click on the touchpad</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="138"/>
        <source>Scroll bar slides with finger</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Scroll bar slides with finger</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="155"/>
        <source>Scrolling area</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Scrolling area</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="157"/>
        <source>Disable scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="158"/>
        <source>Edge scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="159"/>
        <source>Two-finger scrolling in the middle area</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrialDialog</name>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="12"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="37"/>
        <source>Yinhe Kylin OS(Trail Version) Disclaimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="46"/>
        <source>Dear customer:
    Thank you for trying Yinhe Kylin OS(trail version)! This version is free for users who only try out, no commercial purpose is permitted. The trail period lasts one year and it starts from the ex-warehouse time of the OS. No after-sales service is provided during the trail stage. If any security problems occurred when user put important files or do any commercial usage in system, all consequences are taken by users. Kylin software Co., Ltd. take no legal risk in trail version.
    During trail stage,if you want any technology surpport or activate the system, please buy“Yinhe Kylin Operating System”official version or authorization by contacting 400-089-1870.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="54"/>
        <source>Kylin software Co., Ltd.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="62"/>
        <source>www.Kylinos.cn</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkccAbout</name>
    <message>
        <location filename="../../ukccabout.cpp" line="60"/>
        <location filename="../../ukccabout.cpp" line="82"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="89"/>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="96"/>
        <source>The control panel provides a friendly graphical user interface to manage common configuration items of the operating system. System configuration provides system, equipment, personalization, network, account, time and date, account, time and date, update, notification and operation module operations. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="104"/>
        <source>Service and Support:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkmediaInputWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="47"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="52"/>
        <source>Input Device</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Input Device</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="54"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="59"/>
        <source>Input Level</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Input Level</extra-contents_path>
    </message>
</context>
<context>
    <name>UkmediaMainWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_main_widget.cpp" line="2438"/>
        <location filename="../../../plugins/devices/audio/ukmedia_main_widget.cpp" line="2621"/>
        <location filename="../../../plugins/devices/audio/ukmedia_main_widget.cpp" line="2710"/>
        <location filename="../../../plugins/devices/audio/ukmedia_main_widget.cpp" line="2723"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkmediaOutputWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="67"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="73"/>
        <source>Output Device:</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Output Device</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="76"/>
        <source>Master Volume</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Master Volume</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="81"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Balance</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="84"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="82"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkmediaSoundEffectsWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="52"/>
        <source>System Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="55"/>
        <source>Sound Theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Sound Theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="58"/>
        <source>Alert Sound</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Alert Sound</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="63"/>
        <source>Poweroff Music</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Poweroff Music</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="65"/>
        <source>Startup Music</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Startup Music</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="67"/>
        <source>Wakeup Music</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Wakeup Music</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="71"/>
        <source>Logout Music</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Logout Music</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="61"/>
        <source>Beep Switch</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Beep Switch</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="69"/>
        <source>Volume Change</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Volume Change</extra-contents_path>
    </message>
</context>
<context>
    <name>UkmediaVolumeControl</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="71"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="96"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="100"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="114"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="140"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="166"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="247"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="251"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="263"/>
        <source>pa_context_set_sink_volume_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="135"/>
        <source>pa_context_set_source_mute_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="280"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="284"/>
        <source>pa_context_set_source_output_volume() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="296"/>
        <source>pa_context_set_source_output_mute() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="308"/>
        <source>pa_context_set_card_profile_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="322"/>
        <source>pa_context_set_default_sink() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="336"/>
        <source>pa_context_set_default_source() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="350"/>
        <source>pa_context_set_sink_port_by_name() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="364"/>
        <source>pa_context_set_source_port_by_name() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="393"/>
        <source> (plugged in)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="397"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="529"/>
        <source> (unavailable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="399"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="526"/>
        <source> (unplugged)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="637"/>
        <source>Failed to read data from stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="688"/>
        <source>Peak detect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="689"/>
        <source>Failed to create monitoring stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="704"/>
        <source>Failed to connect monitoring stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="801"/>
        <source>Ignoring sink-input due to it being designated as an event and thus handled by the Event widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1098"/>
        <source>Establishing connection to PulseAudio. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UnifiedOutputConfig</name>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="76"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="105"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="110"/>
        <source>arrow-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="111"/>
        <source>90° arrow-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="112"/>
        <source>arrow-down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="113"/>
        <source>90° arrow-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="142"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="147"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="315"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="173"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="274"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="280"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="307"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="325"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Update</name>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="26"/>
        <location filename="../../../plugins/security-updates/update/update.cpp" line="33"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="44"/>
        <location filename="../../../plugins/security-updates/update/update.cpp" line="81"/>
        <source>System Update</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/update/System Update</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="94"/>
        <source>Last check time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="139"/>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateDbus</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatedbus.cpp" line="63"/>
        <source>System-Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatedbus.cpp" line="66"/>
        <source>ukui-control-center-update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateLog</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatelog.cpp" line="17"/>
        <source>Update log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateSource</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatesource.cpp" line="80"/>
        <source>Connection failed, please reconnect!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Upgrade</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/upgrade.cpp" line="7"/>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserInfo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="41"/>
        <source>Current User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="309"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="147"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Password</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="331"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="149"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="188"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Type</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="353"/>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="422"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="151"/>
        <source>Login no passwd</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Login no passwd</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="153"/>
        <source>enable autoLogin</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/enable autoLogin</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="500"/>
        <source>Automatic login at boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="568"/>
        <source>Other Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="71"/>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="835"/>
        <source>root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="831"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="833"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="156"/>
        <source>CurrentUser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="157"/>
        <source>OthersUser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="184"/>
        <source>Passwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="192"/>
        <source>Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="243"/>
        <source>LoginWithoutPwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="263"/>
        <source>AutoLoginOnBoot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="489"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="489"/>
        <source>The user is logged in, please delete the user after logging out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserInfoIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="77"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="146"/>
        <source>Current User</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Current User</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="289"/>
        <source>Change phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="334"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="157"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="1132"/>
        <source>Change pwd</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Change pwd</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="385"/>
        <source>User group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="411"/>
        <source>Del user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="498"/>
        <source>system reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="553"/>
        <source>Unclosed apps start after a restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="622"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="149"/>
        <source>Other Users</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Other Users</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="61"/>
        <source>User Info Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="152"/>
        <source>Change Tel</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Change Tel</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="180"/>
        <source>Delete user</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Delete user</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="193"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="195"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="204"/>
        <source>root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="434"/>
        <source>Add new user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="743"/>
        <source>set pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="757"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UtilsForUserinfo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="31"/>
        <source>Passwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="34"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="37"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="198"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="200"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vino</name>
    <message>
        <location filename="../../../plugins/system/vino/vino.cpp" line="24"/>
        <source>Vino</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vpn</name>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.ui" line="53"/>
        <source>Add Vpn Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.cpp" line="102"/>
        <source>Add vpn connect</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vpn/Add vpn connect</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.cpp" line="28"/>
        <source>Vpn</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Wallpaper</name>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="103"/>
        <source>Desktop Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="398"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="537"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="128"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Browse</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="544"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="130"/>
        <source>Online Picture</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Online Picture</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="576"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="139"/>
        <source>Reset To Default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Reset To Default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="527"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="569"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="331"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="53"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="126"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="156"/>
        <source>picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="156"/>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="172"/>
        <source>scaled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="172"/>
        <source>wallpaper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="172"/>
        <source>centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="172"/>
        <source>stretched</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="482"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="482"/>
        <source>allFiles(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="522"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="564"/>
        <source>select custom wallpaper file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="523"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="565"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="524"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="566"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="525"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="567"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="526"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="568"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="812"/>
        <source>unify output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="816"/>
        <source>night mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/night mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="723"/>
        <source>Some applications need to be logouted to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="274"/>
        <source>Night Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="294"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="309"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="325"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="2066"/>
        <source>Custom Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="336"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="362"/>
        <source>Color Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="365"/>
        <source>Warmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="368"/>
        <source>Colder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="683"/>
        <source>Multi-screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="688"/>
        <source>First Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="689"/>
        <source>Clone Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="690"/>
        <source>Extend Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="691"/>
        <source>Vice Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="711"/>
        <location filename="../../../plugins/system/touchscreen/widget.cpp" line="114"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchscreen/monitor</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="722"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="824"/>
        <source>Theme follow night mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="878"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="883"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="884"/>
        <source>Not Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="2066"/>
        <source>All Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="2066"/>
        <source>Follow the sunrise and sunset(17:55-06:23)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="2342"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="2357"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/Brightness</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1561"/>
        <source>please insure at least one output!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1358"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1561"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1568"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="879"/>
        <source>After modifying the resolution or refresh rate, due to compatibility issues between the display device and the graphics card, the display may be abnormal or unable to display
the settings will be saved after 14 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="893"/>
        <source>After modifying the resolution or refresh rate, due to compatibility issues between the display device and the graphics card, the display may be abnormal or unable to display 
the settings will be saved after %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1359"/>
        <source>Open time should be earlier than close time!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1569"/>
        <source>Sorry, your configuration could not be applied.
Common reasons are that the overall screen size is too big, or you enabled more displays than supported by your GPU.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/widget.cpp" line="116"/>
        <source>touch id</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchscreen/touch id</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/widget.cpp" line="461"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WlanConnect</name>
    <message>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.ui" line="14"/>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="67"/>
        <source>WlanConnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.ui" line="35"/>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="132"/>
        <source>WLAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.ui" line="94"/>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="134"/>
        <source>open</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wlanconnect/open</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.ui" line="163"/>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="131"/>
        <source>Advanced settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wlanconnect/Advanced settings&quot;</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="780"/>
        <source>card</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="275"/>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="817"/>
        <location filename="../../../plugins/network/wlanconnect/wlanconnect.cpp" line="879"/>
        <source>connected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addShortcutDialog</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="103"/>
        <source>Exec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="174"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="214"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="352"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="359"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="441"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="154"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="422"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="248"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="65"/>
        <source>Add custom shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="79"/>
        <source>Please enter a shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="240"/>
        <source>Desktop files(*.desktop)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="247"/>
        <source>select desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="269"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="288"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="299"/>
        <source>Invalid application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="271"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="284"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="295"/>
        <source>Shortcut conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="273"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="286"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="297"/>
        <source>Invalid shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="275"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="282"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="301"/>
        <source>Name repetition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="307"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>changtimedialog</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="115"/>
        <source>current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="200"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="321"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="398"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="472"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="574"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="593"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ksc_main_page_widget</name>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_main_page_widget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_main_page_widget.ui" line="158"/>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_main_page_widget.cpp" line="41"/>
        <source>Run Security Center</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ksc_module_func_widget</name>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.ui" line="182"/>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.ui" line="198"/>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.cpp" line="20"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.cpp" line="82"/>
        <source>Security Scan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/securitycenter/Security Scan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.cpp" line="84"/>
        <source>Account Protection</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/securitycenter/Account Protection</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.cpp" line="86"/>
        <source>Network Protection</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/securitycenter/Network Protection</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.cpp" line="88"/>
        <source>Application Protection</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/securitycenter/Application Protection</extra-contents_path>
    </message>
</context>
<context>
    <name>m_updatelog</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="57"/>
        <source>No content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="113"/>
        <source>Update Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="531"/>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="564"/>
        <source>Search content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="611"/>
        <source>History Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>networkaccount</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/networkaccount.cpp" line="24"/>
        <source>Cloud Account</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
