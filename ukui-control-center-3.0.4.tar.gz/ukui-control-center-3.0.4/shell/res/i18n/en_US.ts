<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="47"/>
        <source>System Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="498"/>
        <source>version</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/version</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="138"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="145"/>
        <source>Kylin Linux Desktop V10 (SP1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="181"/>
        <source>Copyright © 2009-2021 KylinSoft. All rights reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="269"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="500"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Kernel</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="308"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="502"/>
        <source>CPU</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/CPU</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="356"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="504"/>
        <source>Memory</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Memory</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="404"/>
        <source>Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="458"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="506"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Desktop</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="488"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="508"/>
        <source>User</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/User</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="534"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="510"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Status</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="94"/>
        <source>Active Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="573"/>
        <source>DataRes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="603"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="669"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="514"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Protocol</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.ui" line="639"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="262"/>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="512"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/about/Active</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="63"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="266"/>
        <source>Activated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="306"/>
        <source>expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="309"/>
        <source>Extend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/about.cpp" line="260"/>
        <source>Inactivated</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddAppDialog</name>
    <message>
        <location filename="../../../plugins/system/defaultapp/addappdialog.ui" line="74"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/addappdialog.ui" line="81"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddAutoBoot</name>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="32"/>
        <source>Add AutoBoot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="162"/>
        <source>Add autoboot program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="218"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="39"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="109"/>
        <source>Program name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="246"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="40"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="110"/>
        <source>Program exec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="361"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="274"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="41"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="111"/>
        <source>Program comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="429"/>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="177"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.ui" line="454"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="168"/>
        <source>Desktop files(*.desktop)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="175"/>
        <source>select autoboot desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="176"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="223"/>
        <source>desktop file not allowed add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/addautoboot.cpp" line="272"/>
        <source>desktop file not exist</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppDetail</name>
    <message>
        <location filename="../../../plugins/messages-task/notice/appdetail.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/appdetail.ui" line="97"/>
        <source>App</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/appdetail.ui" line="163"/>
        <source>Allow notification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/appdetail.ui" line="213"/>
        <source>Number of notification centers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/appdetail.ui" line="290"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/appdetail.ui" line="309"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppUpdateWid</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="73"/>
        <source>Lack of local disk space!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="79"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="102"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="402"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="627"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="685"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="848"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="96"/>
        <source>Network abnormal!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="111"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="127"/>
        <source>Download failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="113"/>
        <source>failed to get from the source!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="129"/>
        <source>The download cache has been removed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="288"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="291"/>
        <source>Being installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="316"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="325"/>
        <source>Update succeeded!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="336"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="346"/>
        <source>Update failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="339"/>
        <source>Failure reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="396"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="614"/>
        <source>details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="445"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="512"/>
        <source>Update log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="492"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="493"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="498"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="513"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="688"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="689"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="691"/>
        <source>Newest:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="521"/>
        <source>Download completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="528"/>
        <source>Download size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="555"/>
        <source>Current version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="608"/>
        <source>back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="633"/>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="636"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="647"/>
        <source>A single update will not automatically backup the system, if you want to backup, please click Update All.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="648"/>
        <source>Prompt information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="656"/>
        <source>Do not backup, continue to update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="657"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="709"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="660"/>
        <source>This time will no longer prompt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="717"/>
        <source>Calculate the download progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="728"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="735"/>
        <source>Get depends failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="785"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="788"/>
        <source>In the update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="175"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="713"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="826"/>
        <source>Ready to install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="303"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="305"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="306"/>
        <source>Update succeeded , It is recommended that you restart later!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="310"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="312"/>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="313"/>
        <source>Update succeeded , It is recommended that you log out later and log in again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/appupdate.cpp" line="907"/>
        <source>No content.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Area</name>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="26"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="42"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="56"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="157"/>
        <source>Regional Format</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Regional Format</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="169"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="395"/>
        <source>Current Region</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Current Region</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="252"/>
        <source>First Day Of The Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="313"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="397"/>
        <source>Calendar</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Calendar</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="374"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="401"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Date</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="435"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="403"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="508"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="408"/>
        <source>lunar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="411"/>
        <source>monday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="474"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="159"/>
        <source>First Language</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/First Language</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="259"/>
        <source>US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="260"/>
        <source>CN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="228"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="161"/>
        <source>Language for system windows,menus and web pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="167"/>
        <source>addwgt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="186"/>
        <source>Add language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="227"/>
        <source>Simplified Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="399"/>
        <source>First Day Of Week</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/area/First Day Of Week</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="405"/>
        <source>solar calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="412"/>
        <source>sunday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="423"/>
        <source>12 Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="424"/>
        <source>24 Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="534"/>
        <source>Modify the current region need to logout to take effect, whether to logout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="538"/>
        <source>Modify the first language need to reboot to take effect, whether to reboot?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="535"/>
        <source>Logout later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="536"/>
        <source>Logout now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="539"/>
        <source>Reboot later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="540"/>
        <source>Reboot now</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Audio</name>
    <message>
        <location filename="../../../plugins/devices/audio/audio.ui" line="26"/>
        <location filename="../../../plugins/devices/audio/audio.cpp" line="27"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutoBoot</name>
    <message>
        <location filename="../../../plugins/system/autoboot/autoboot.ui" line="88"/>
        <location filename="../../../plugins/system/autoboot/autoboot.cpp" line="190"/>
        <source>Autoboot Settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Autoboot Settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/autoboot.cpp" line="63"/>
        <source>Auto Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/autoboot.cpp" line="149"/>
        <source>Add autoboot app </source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Add autoboot app</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/autoboot.cpp" line="228"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/autoboot.cpp" line="232"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/autoboot/autoboot.cpp" line="293"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Backup</name>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="53"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="45"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="88"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="69"/>
        <source>Back up your files to other drives, and when the original files are lost, damaged, or deleted, 
you can restore them to ensure the integrity of your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="113"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="91"/>
        <source>Begin backup</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/backup/Begin backup</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="157"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="89"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="173"/>
        <source>View a list of backed-upfiles to backed up files to the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="213"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="93"/>
        <source>Begin restore</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/backup/Begin restore</extra-contents_path>
    </message>
</context>
<context>
    <name>BiometricEnrollDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.ui" line="290"/>
        <source>Continue to enroll </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.ui" line="322"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="121"/>
        <source>FingerPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="123"/>
        <source>Fingervein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="125"/>
        <source>Iris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="127"/>
        <source>Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="129"/>
        <source>VoicePrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="139"/>
        <source>Enroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="142"/>
        <source>Verify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="145"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="173"/>
        <source>Permission is required.
Please authenticate yourself to continue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="197"/>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="369"/>
        <source>Enroll successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="263"/>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="371"/>
        <source>Verify successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="266"/>
        <source>Not Match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="490"/>
        <source>D-Bus calling error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="499"/>
        <source>Device is busy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="503"/>
        <source>No such device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricenroll.cpp" line="507"/>
        <source>Permission denied</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BiometricMoreInfoDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="76"/>
        <source>Biometrics </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="166"/>
        <source>Default device </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="208"/>
        <source>Verify Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="215"/>
        <source>Bus Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="222"/>
        <source>Device Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="243"/>
        <source>Storage Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.ui" line="250"/>
        <source>Identification Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="77"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="77"/>
        <source>Unconnected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="126"/>
        <source>FingerPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="128"/>
        <source>Fingervein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="130"/>
        <source>Iris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="132"/>
        <source>Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="134"/>
        <source>VoicePrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="143"/>
        <source>Hardware Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="145"/>
        <source>Software Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="147"/>
        <source>Mix Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="149"/>
        <source>Other Verification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="157"/>
        <source>Device Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="159"/>
        <source>OS Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="161"/>
        <source>Mix Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="169"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="171"/>
        <source>USB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="173"/>
        <source>PCIE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="175"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="177"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="185"/>
        <source>Hardware Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="187"/>
        <source>Software Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="189"/>
        <source>Mix Identification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricmoreinfo.cpp" line="191"/>
        <source>Other Identification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Biometrics</name>
    <message>
        <location filename="../../../plugins/account/biometrics/biometrics.cpp" line="24"/>
        <source>Biometrics</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BlueToothMain</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="448"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1035"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="473"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1061"/>
        <source>Turn on :</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Turn on Bluetooth</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="506"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1095"/>
        <source>Bluetooth adapter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="534"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1128"/>
        <source>Show icon on taskbar</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Show icon on taskbar</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="567"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1160"/>
        <source>Discoverable by nearby Bluetooth devices</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/bluetooth/Discoverable</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="746"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1200"/>
        <source>My Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="765"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1217"/>
        <source>Other Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="865"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1664"/>
        <source>Bluetooth adapter is abnormal !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothmain.cpp" line="1665"/>
        <source>You can refer to the rfkill command for details.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Bluetooth</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetooth.cpp" line="6"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BluetoothNameLabel</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="37"/>
        <source>Double-click to change the device name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="93"/>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="188"/>
        <source>Can now be found as &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="104"/>
        <source>Tip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/bluetoothnamelabel.cpp" line="105"/>
        <source>The length of the device name does not exceed %1 characters !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CertificationDialog</name>
    <message>
        <location filename="../../../plugins/network/proxy/certificationdialog.ui" line="26"/>
        <location filename="../../../plugins/network/proxy/certificationdialog.ui" line="88"/>
        <source>UserCertification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/certificationdialog.ui" line="161"/>
        <source>User:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/certificationdialog.ui" line="238"/>
        <source>Passwd:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/certificationdialog.ui" line="298"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/certificationdialog.cpp" line="33"/>
        <source>Certification</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeFaceDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.ui" line="96"/>
        <source>Change User Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.ui" line="185"/>
        <source>System Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.ui" line="246"/>
        <source>Select face from local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.ui" line="336"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="200"/>
        <source>select custom face file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="201"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="202"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="203"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="204"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.ui" line="317"/>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="205"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="220"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changefacedialog.cpp" line="221"/>
        <source>The avatar is larger than 1M, please choose again</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="79"/>
        <source>User Group Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="194"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="247"/>
        <source>User group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="294"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="338"/>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="346"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="338"/>
        <source>Invalid Id!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="341"/>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="349"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="346"/>
        <source>Invalid Group Name!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeProjectionName</name>
    <message>
        <location filename="../../../plugins/devices/projection/changeprojectionname.ui" line="26"/>
        <source>Change Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/changeprojectionname.ui" line="96"/>
        <source>Changename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/changeprojectionname.ui" line="132"/>
        <source>ChangeProjectionname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/changeprojectionname.ui" line="194"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/changeprojectionname.ui" line="213"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/changeprojectionname.cpp" line="24"/>
        <source>Name is too long, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePwdDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.ui" line="130"/>
        <source>Change Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.ui" line="314"/>
        <source>Cur pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.ui" line="359"/>
        <source>New pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.ui" line="404"/>
        <source>New pwd sure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.ui" line="524"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.ui" line="546"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="64"/>
        <source>Change pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="172"/>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="444"/>
        <source>Current Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="173"/>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="445"/>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="453"/>
        <source>New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="174"/>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="446"/>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="454"/>
        <source>New Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="193"/>
        <source>Authentication failed, input authtok again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="269"/>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="399"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="361"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changepwddialog.cpp" line="363"/>
        <source>Same with old pwd</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeTypeDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="85"/>
        <source>Change Account Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="409"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="312"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="359"/>
        <source>Users can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="456"/>
        <source>Users cannot change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="505"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.ui" line="527"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.cpp" line="38"/>
        <source>Change type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changetypedialog.cpp" line="41"/>
        <location filename="../../../plugins/account/userinfo/changetypedialog.cpp" line="42"/>
        <source>Ensure that must have admin on system</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserName</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusername.ui" line="26"/>
        <location filename="../../../plugins/account/userinfo/changeusername.ui" line="90"/>
        <source>Change Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusername.ui" line="181"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusername.ui" line="200"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusername.cpp" line="25"/>
        <source>Name already in use, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeValidDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.ui" line="138"/>
        <source>Password Validity Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.ui" line="308"/>
        <source>Current passwd validity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.ui" line="396"/>
        <source>Adjust date to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.ui" line="517"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.ui" line="524"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.cpp" line="41"/>
        <source>Change valid</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangtimeDialog</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="161"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="162"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="163"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="164"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="61"/>
        <source>     B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="174"/>
        <source>     R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="199"/>
        <source>     G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="227"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="259"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.cpp" line="92"/>
        <source>Custom color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="266"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="288"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="50"/>
        <source>Add New Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="77"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="124"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="172"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.cpp" line="206"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateUserDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="115"/>
        <source>Add New Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="212"/>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="117"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="260"/>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="118"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="308"/>
        <source>PasswordSure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="367"/>
        <source>Account Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="468"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="481"/>
        <source>Users cannot change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="598"/>
        <source>Users can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="585"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="673"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.ui" line="692"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="48"/>
        <source>Add new user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="119"/>
        <source>Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="154"/>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="297"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="249"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="413"/>
        <source>The user name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="415"/>
        <source>Must be begin with lower letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="418"/>
        <source>Can not contain capital letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="440"/>
        <source>Name already in use, change another one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="442"/>
        <source>Name corresponds to group already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="447"/>
        <source>Name length must less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="449"/>
        <source>Can only contain letters,digits,underline!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createuserdialog.cpp" line="454"/>
        <source>Username&apos;s folder exists, change another one</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomLineEdit</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/customlineedit.cpp" line="28"/>
        <source>New Shortcut...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateTime</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="26"/>
        <source>DateTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="62"/>
        <source>current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="193"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="212"/>
        <source>Change timezone</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Change timezone</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="218"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="210"/>
        <source>Change time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Change time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="375"/>
        <source>titleLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="382"/>
        <source>summaryLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="85"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="147"/>
        <source>Other Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="160"/>
        <source>24-hour clock</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/24-hour clock</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="163"/>
        <source>Sync from network</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/date/Sync from network</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="260"/>
        <source>Add time zones to display the time,only 5 can be added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="284"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="605"/>
        <source>Add Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="413"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="447"/>
        <source>Time Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="449"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="451"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="459"/>
        <source>Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="464"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="465"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="594"/>
        <source>change time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="607"/>
        <source>Change Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="820"/>
        <source>  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="821"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="826"/>
        <source>Sync from network failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultApp</name>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="38"/>
        <source>Default App</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="65"/>
        <source>No program available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="125"/>
        <source>Browser</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Browser</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="127"/>
        <source>Mail</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Mail</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="129"/>
        <source>Image Viewer</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Image Viewer</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="131"/>
        <source>Audio Player</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Audio Player</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="133"/>
        <source>Video Player</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Video Player</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.cpp" line="135"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/defaultapp/Text Editor</extra-contents_path>
    </message>
</context>
<context>
    <name>DefaultAppWindow</name>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="53"/>
        <source>Select Default Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="130"/>
        <source>Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="216"/>
        <source>Mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="299"/>
        <source>Image Viewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="382"/>
        <source>Audio Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="465"/>
        <source>Video Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="548"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/defaultapp/defaultapp.ui" line="594"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineGroupItem</name>
    <message>
        <location filename="../../../plugins/account/userinfo/definegroupitem.cpp" line="53"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/definegroupitem.cpp" line="62"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineShortcutItem</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/defineshortcutitem.cpp" line="58"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="68"/>
        <source>Are you sure to delete the group:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="73"/>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="74"/>
        <source>which will make some file components in the file system invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="81"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="87"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="53"/>
        <source>Delete user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelUserDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/deluserdialog.ui" line="192"/>
        <source>keep the user&apos;s data, like desktop,documents, favorites, music, pictures and so on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deluserdialog.ui" line="260"/>
        <source>delete whole data belong user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deluserdialog.ui" line="318"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deluserdialog.ui" line="340"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deluserdialog.cpp" line="98"/>
        <source>Delete the user &apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deluserdialog.cpp" line="99"/>
        <source>&apos;and:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Desktop</name>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="50"/>
        <location filename="../../../plugins/personalized/desktop/desktop.cpp" line="133"/>
        <source>Icon Show On Desktop</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/desktop/Icon Show On Desktop</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="128"/>
        <source>Computerdesktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="219"/>
        <source>Trashdesktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="310"/>
        <source>Homedesktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="401"/>
        <source>Volumedesktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="492"/>
        <source>Networkdesktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="527"/>
        <source>Set Start Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="586"/>
        <source>Always use the start menu in full screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="617"/>
        <source>Icon Lock on Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="711"/>
        <source>Computermenu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="802"/>
        <source>Settingmenu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="893"/>
        <source>Filesystemmenu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="984"/>
        <source>Trashmenu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.ui" line="1035"/>
        <location filename="../../../plugins/personalized/desktop/desktop.cpp" line="135"/>
        <source>Tray icon</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/desktop/Tray icon</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/desktop/desktop.cpp" line="53"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceInfoItem</name>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="33"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="37"/>
        <source>Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="41"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="145"/>
        <source>Device connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/bluetooth/deviceinfoitem.cpp" line="149"/>
        <source>Device not connected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceType</name>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricdeviceinfo.cpp" line="40"/>
        <source>FingerPrint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricdeviceinfo.cpp" line="42"/>
        <source>FingerVein</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricdeviceinfo.cpp" line="44"/>
        <source>Iris</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricdeviceinfo.cpp" line="46"/>
        <source>Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/biometricdeviceinfo.cpp" line="48"/>
        <source>VoicePrint</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayPerformanceDialog</name>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="214"/>
        <source>Display Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="297"/>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="376"/>
        <source>Applicable to machine with discrete graphics, which can accelerate the rendering of 3D graphics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="392"/>
        <source>(Note: not support connect graphical with xmanager on windows.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="462"/>
        <source>Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="538"/>
        <source>Applicable to machine with integrated graphics,  there is no 3D graphics acceleration. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="554"/>
        <source>(Note: need connect graphical with xmanager on windows, use this option.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="624"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="700"/>
        <source>Auto select according to environment, delay the login time (about 0.5 sec).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="721"/>
        <source>Threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="744"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="757"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="772"/>
        <source>(Note: select this option to use 3D graphics acceleration and xmanager.)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplaySet</name>
    <message>
        <location filename="../../../plugins/system/display/display.cpp" line="33"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayWindow</name>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="32"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="139"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="185"/>
        <source>set as home screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="241"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="302"/>
        <source>open monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="356"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="398"/>
        <source>unify output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="540"/>
        <source>follow the sunrise and sunset(17:55-05:04)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="604"/>
        <source>custom time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="668"/>
        <source>opening time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="751"/>
        <source>closing time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="846"/>
        <source>color temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="853"/>
        <source>warm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="876"/>
        <source>cold</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="275"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="297"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="50"/>
        <source>Edit User Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="77"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="124"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="175"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="229"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="229"/>
        <source>Invalid Id!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="232"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="299"/>
        <source>Edit user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExperiencePlan</name>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="79"/>
        <source>User Experience</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="130"/>
        <source>Join in user Experience plan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="172"/>
        <source>User experience plan terms, see</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.ui" line="179"/>
        <source>《User Experience plan》</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/experienceplan/experienceplan.cpp" line="33"/>
        <source>Experienceplan</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fonts</name>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="47"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="65"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="119"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="129"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Font size</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="169"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="131"/>
        <source>Fonts select</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Fonts select</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="302"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="135"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Reset to default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="238"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="133"/>
        <source>Mono font</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/fonts/Mono font</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="144"/>
        <source>11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="144"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="144"/>
        <source>13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="144"/>
        <source>14</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="144"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="145"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FrameItem</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="117"/>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="132"/>
        <source>Sync failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="120"/>
        <source>Change configuration file failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="123"/>
        <source>Configuration file not exist,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="126"/>
        <source>Cloud verifyed file download failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/frameitem.cpp" line="129"/>
        <source>OSS access failed,please relogin!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryUpdateListWig</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/historyupdatelistwig.cpp" line="98"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/historyupdatelistwig.cpp" line="100"/>
        <source>Failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputPwdDialog</name>
    <message>
        <location filename="../../../plugins/network/vino/inputpwddialog.cpp" line="28"/>
        <source>Set Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/inputpwddialog.cpp" line="62"/>
        <location filename="../../../plugins/network/vino/inputpwddialog.cpp" line="81"/>
        <source>Password can not be blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/inputpwddialog.cpp" line="51"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/inputpwddialog.cpp" line="56"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/inputpwddialog.cpp" line="86"/>
        <source>less than or equal to 8</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ItemList</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>ScreenSaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Quick Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="40"/>
        <source>Wallpaper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>Themes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>TouchPad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>KeyBoard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="41"/>
        <source>ShortCut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Date/Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Default Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="42"/>
        <source>Peony</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Weather</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/itemlist.h" line="43"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbPreviewFrame</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/kbpreviewframe.cpp" line="321"/>
        <source>No preview found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/kbpreviewframe.cpp" line="325"/>
        <source>Unable to open Preview !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbdLayoutManager</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="68"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="144"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="222"/>
        <source>Variant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="270"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="61"/>
        <source>Add Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="237"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="291"/>
        <source>Keyboard Preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyValueConverter</name>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="46"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="49"/>
        <source>Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="52"/>
        <source>Personalized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="55"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="58"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="61"/>
        <source>Datetime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="64"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="67"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardControl</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="91"/>
        <source>Keys Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="159"/>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="120"/>
        <source>Enable repeat key</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Enable repeat key</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="249"/>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="122"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Delay</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="262"/>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="294"/>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="368"/>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="124"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="381"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="413"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="475"/>
        <source>Input characters to test the repetition effect：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="572"/>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="128"/>
        <source>Tip of keyboard</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Tip of keyboard</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="647"/>
        <source>Enable numlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="699"/>
        <source>Input Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="872"/>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="131"/>
        <source>Input Set</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Input Set</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.ui" line="767"/>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="129"/>
        <source>Keyboard layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="42"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="126"/>
        <source>Input characters to test the repetition effect:</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/keyboard/Input characters to test the repetition effect:</extra-contents_path>
    </message>
</context>
<context>
    <name>KeyboardPainter</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="31"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="67"/>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="69"/>
        <source>Keyboard layout levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="67"/>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="69"/>
        <source>Level %1, %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LayoutManager</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="121"/>
        <source>Manager Keyboard Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="234"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="250"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="293"/>
        <source>Variant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="351"/>
        <source>Layout installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="399"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="431"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="450"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LoginDialog</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="40"/>
        <source>Forget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="43"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="44"/>
        <source>User Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="45"/>
        <source>Quick Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="104"/>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="355"/>
        <source>Your code here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="177"/>
        <source>Your phone number here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="96"/>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="221"/>
        <source>Your account/phone/email here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/logindialog.cpp" line="235"/>
        <source>Your password here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MCodeWidget</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/mcodewidget.cpp" line="33"/>
        <source>SongTi</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainDialog</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="33"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="283"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="307"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="314"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="654"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="869"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="880"/>
        <source>Sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="34"/>
        <source>Sign up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="56"/>
        <source>Login in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="372"/>
        <source>Error code:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="372"/>
        <source>!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="374"/>
        <source>Internal error occurred!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="375"/>
        <source>Failed to sign up!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="376"/>
        <source>Failed attempt to return value!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="377"/>
        <source>Check your connection!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="378"/>
        <source>Failed to get by phone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="379"/>
        <source>Failed to get by user!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="380"/>
        <source>Failed to reset password!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="381"/>
        <source>Timeout!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="382"/>
        <source>Phone binding falied!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="383"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="404"/>
        <source>Please check your information!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="384"/>
        <source>Please check your account!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="385"/>
        <source>Failed due to server error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="386"/>
        <source>User and passsword can&apos;t be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="387"/>
        <source>User existing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="389"/>
        <source>Network can not reach!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="390"/>
        <source>Phone can&apos;t be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="388"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="391"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="397"/>
        <source>Account or password error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="392"/>
        <source>Phone number already in used!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="393"/>
        <source>Please check your format!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="394"/>
        <source>Your are reach the limit!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="395"/>
        <source>Please check your phone number!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="396"/>
        <source>Please check your code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="398"/>
        <source>User has bound the phone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="399"/>
        <source>Sending code error occurred!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="400"/>
        <source>Phone code is expired!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="401"/>
        <source>Phone code error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="402"/>
        <source>Code can not be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="403"/>
        <source>MCode can not be empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="486"/>
        <source>Your code is wrong!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="500"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="599"/>
        <source>Please check your phone!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="844"/>
        <location filename="../../../plugins/account/networkaccount/maindialog.h" line="55"/>
        <source>Sign in Cloud</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="629"/>
        <source>Resend ( %1 )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/maindialog.cpp" line="634"/>
        <source>Get</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWidget</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="492"/>
        <source>Your account：%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="512"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1226"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1243"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="881"/>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="524"/>
        <source>Sign in</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/networkaccount/Sign in</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="441"/>
        <source>Waiting for initialization...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="407"/>
        <source>Logout failed,please check your connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1200"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1215"/>
        <source>Stop sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="885"/>
        <source>Sync your settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="888"/>
        <source>Your account:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="889"/>
        <source>Auto sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="433"/>
        <source>The latest time sync is: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="233"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="338"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="640"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="660"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="717"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="982"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1001"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1314"/>
        <source>Network can not reach!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="578"/>
        <source>Waitting for sync!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="872"/>
        <source>Synchronize your personalized settings and data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="750"/>
        <source>The Cloud Account Service version is out of date!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="947"/>
        <source>KylinID open error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1028"/>
        <source>Unauthorized device or OSS falied.
Please retry or relogin!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1032"/>
        <source>Authorization failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="677"/>
        <source>This operation may cover your settings!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1076"/>
        <source>Please check your connetion!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1299"/>
        <source>Kylin Cloud Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1302"/>
        <source>Cloud ID desktop message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="103"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="461"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="471"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.cpp" line="1165"/>
        <location filename="../../../plugins/account/networkaccount/mainwidget.h" line="109"/>
        <source>Disconnected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../mainwindow.cpp" line="410"/>
        <location filename="../../mainwindow.cpp" line="626"/>
        <location filename="../../mainwindow.cpp" line="844"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="390"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="419"/>
        <source>Main menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="420"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="421"/>
        <source>Maximize/Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="422"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="486"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="488"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="490"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="631"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="959"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="959"/>
        <source>This function has been controlled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MouseControl</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="53"/>
        <source>Mouse Key Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="132"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="171"/>
        <source>Hand habit</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Hand habit</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="219"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="169"/>
        <source>mouse wheel speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/mouse wheel speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="257"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="636"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1286"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="304"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="686"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1336"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="378"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="173"/>
        <source>Doubleclick  delay</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Doubleclick  delay</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="416"/>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="463"/>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="516"/>
        <source>Pointer Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="598"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="175"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="757"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="179"/>
        <source>Acceleration</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Acceleration</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="822"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="181"/>
        <source>Visibility</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Visibility</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="900"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="183"/>
        <source>Pointer size</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Pointer size</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="950"/>
        <source>Cursor Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1017"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="185"/>
        <source>Enable flashing on text area</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Enable flashing on text area</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1098"/>
        <source>Cursor weight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1123"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1158"/>
        <source>Coarse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.ui" line="1261"/>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="187"/>
        <source>Cursor speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/mouse/Cursor speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="103"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="201"/>
        <source>Lefthand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="202"/>
        <source>Righthand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="218"/>
        <source>Default(Recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="219"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="220"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyLabel</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="84"/>
        <source>double-click to test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetConnect</name>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="38"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="105"/>
        <source>Netconnect Status</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/netconnect/Netconnect Status</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="106"/>
        <source>Available Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="129"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="981"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="179"/>
        <source>open wifi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.ui" line="227"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="109"/>
        <source>Network settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/netconnect/Network settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="52"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="521"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="107"/>
        <source>open WLAN</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/netconnect/open WLAN</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="234"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="288"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="796"/>
        <source>No net</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="244"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="297"/>
        <source>Detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="663"/>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="686"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netconnect.cpp" line="969"/>
        <source>Refreshing...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetDetail</name>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="93"/>
        <source>SSID:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="94"/>
        <source>Protocol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="96"/>
        <source>Security Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="97"/>
        <source>Hz:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="98"/>
        <source>Chan:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="99"/>
        <source>Link Speed(rx/tx):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="102"/>
        <source>BandWidth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="103"/>
        <source>IPV4:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="104"/>
        <source>IPV4 Dns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="105"/>
        <source>IPV4 GateWay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="106"/>
        <source>IPV4 Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="107"/>
        <source>IPV6:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="108"/>
        <source>IPV6 Prefix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="109"/>
        <source>IPV6 GateWay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/netconnect/netdetail.cpp" line="110"/>
        <source>Mac:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Notice</name>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.ui" line="62"/>
        <source>Notice Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.ui" line="75"/>
        <location filename="../../../plugins/messages-task/notice/notice.cpp" line="139"/>
        <source>Set notice type of operation center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.ui" line="137"/>
        <source>Show new feature ater system upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.ui" line="212"/>
        <location filename="../../../plugins/messages-task/notice/notice.cpp" line="138"/>
        <source>Get notifications from the app</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/notice/Get notifications from the app</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.ui" line="284"/>
        <source>Show notifications on the lock screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.ui" line="333"/>
        <location filename="../../../plugins/messages-task/notice/notice.cpp" line="140"/>
        <source>Notice Origin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/notice/notice.cpp" line="40"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputConfig</name>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="64"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/resolution</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="93"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/orientation</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="110"/>
        <source>arrow-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="111"/>
        <source>90° arrow-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="113"/>
        <source>arrow-down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="112"/>
        <source>90° arrow-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="125"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/frequency</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="141"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="164"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/screen zoom</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="257"/>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="263"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Power</name>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="54"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <location filename="../../../plugins/system/power/power.cpp" line="622"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="469"/>
        <location filename="../../../plugins/system/power/power.cpp" line="470"/>
        <source>Require password when sleep/hibernation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="473"/>
        <location filename="../../../plugins/system/power/power.cpp" line="474"/>
        <source>Password required when waking up the screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="477"/>
        <source>Press the power button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="481"/>
        <location filename="../../../plugins/system/power/power.cpp" line="482"/>
        <source>Time to close display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="485"/>
        <location filename="../../../plugins/system/power/power.cpp" line="486"/>
        <source>Time to sleep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="489"/>
        <location filename="../../../plugins/system/power/power.cpp" line="490"/>
        <source>Notebook cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="493"/>
        <location filename="../../../plugins/system/power/power.cpp" line="494"/>
        <location filename="../../../plugins/system/power/power.cpp" line="498"/>
        <source>Using power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="497"/>
        <source>Using battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="501"/>
        <location filename="../../../plugins/system/power/power.cpp" line="502"/>
        <source> Time to darken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="505"/>
        <location filename="../../../plugins/system/power/power.cpp" line="506"/>
        <source>Battery level is lower than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="509"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="511"/>
        <location filename="../../../plugins/system/power/power.cpp" line="512"/>
        <source>Low battery notification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="515"/>
        <source>Automatically run saving mode when low battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="516"/>
        <source>Automatically run saving mode when the low battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="519"/>
        <location filename="../../../plugins/system/power/power.cpp" line="520"/>
        <source>Automatically run saving mode when using battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="523"/>
        <location filename="../../../plugins/system/power/power.cpp" line="524"/>
        <source>Display remaining charging time and usage time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="561"/>
        <source>General</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/power/General</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="563"/>
        <source>Select Powerplan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/power/Select Powerplan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="565"/>
        <source>Battery saving plan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/power/Battery saving plan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="571"/>
        <location filename="../../../plugins/system/power/power.cpp" line="631"/>
        <source>nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="571"/>
        <location filename="../../../plugins/system/power/power.cpp" line="631"/>
        <source>blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="571"/>
        <location filename="../../../plugins/system/power/power.cpp" line="582"/>
        <location filename="../../../plugins/system/power/power.cpp" line="631"/>
        <source>suspend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="577"/>
        <location filename="../../../plugins/system/power/power.cpp" line="582"/>
        <location filename="../../../plugins/system/power/power.cpp" line="637"/>
        <source>hibernate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="582"/>
        <source>interactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <location filename="../../../plugins/system/power/power.cpp" line="622"/>
        <source>5min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <source>10minn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>15min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>30min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>1h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>2h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <location filename="../../../plugins/system/power/power.cpp" line="622"/>
        <source>10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>3h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="611"/>
        <location filename="../../../plugins/system/power/power.cpp" line="616"/>
        <source>Balance Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="611"/>
        <location filename="../../../plugins/system/power/power.cpp" line="616"/>
        <source>Save Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="611"/>
        <location filename="../../../plugins/system/power/power.cpp" line="616"/>
        <source>Performance Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="622"/>
        <source>1min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="622"/>
        <source>20min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="571"/>
        <location filename="../../../plugins/system/power/power.cpp" line="582"/>
        <location filename="../../../plugins/system/power/power.cpp" line="631"/>
        <source>shutdown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Printer</name>
    <message>
        <location filename="../../../plugins/devices/printer/printer.ui" line="91"/>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="65"/>
        <source>Add Printers And Scanners</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/printer/Add Printers And Scanners</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.ui" line="169"/>
        <source>List Of Existing Printers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="33"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="117"/>
        <source>Add printers and scanners</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Projection</name>
    <message>
        <location filename="../../../plugins/devices/projection/projection.ui" line="53"/>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="49"/>
        <source>Projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.ui" line="230"/>
        <source>msg info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.ui" line="246"/>
        <source>label for set size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.ui" line="373"/>
        <source>msg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="66"/>
        <source>Open Projection</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/projection/Open Projection</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="255"/>
        <source>Service exception,please restart the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="261"/>
        <source>Network card is not detected or the driver is not supported.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="271"/>
        <source>Please keep WLAN on;
Wireless-network functions will be invalid when the screen projection on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="273"/>
        <source>Please keep WLAN on;
Wireless will be temporarily disconnected when the screen projection on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="280"/>
        <source>After opening the switch button,open the projection screen in the mobile phone drop-down menu,follow the prompts.See the user manual for details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="285"/>
        <source>WLAN is off, please turn on WLAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="291"/>
        <source>Wireless network card is busy. Please try again later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="329"/>
        <source>projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="332"/>
        <source>Projection is </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="332"/>
        <source>on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="332"/>
        <source>off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="333"/>
        <source>Please enable or refresh the scan at the projection device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="333"/>
        <source>You need to turn on the projection again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="344"/>
        <source>Failed to execute. Please reopen the page later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/projection/projection.cpp" line="366"/>
        <source>Add Bluetooths</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Proxy</name>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="53"/>
        <source>Auto Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="129"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="133"/>
        <source>Auto proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Auto proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="204"/>
        <source>Auto url</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="270"/>
        <source>Manual Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="346"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="135"/>
        <source>Manual proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/proxy/Manual proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="436"/>
        <source>Http Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="481"/>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="648"/>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="796"/>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="944"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="516"/>
        <source>Cetification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="603"/>
        <source>Https Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="751"/>
        <source>Ftp Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="899"/>
        <source>Socks Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.ui" line="1041"/>
        <source>List of ignored hosts. more than one entry, please separate with english semicolon(;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="47"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../main.cpp" line="91"/>
        <source>ukui-control-center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="82"/>
        <source>ukui-control-center is already running!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="51"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="59"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="56"/>
        <source>Default App</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="53"/>
        <source>TouchScreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="61"/>
        <source>Auto Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="75"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="78"/>
        <source>Projection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="81"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="83"/>
        <source>Touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="86"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="88"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="91"/>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="93"/>
        <source>Bluetooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="110"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="108"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="112"/>
        <source>Screenlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="115"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="117"/>
        <source>Screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="119"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="133"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="139"/>
        <source>Vino</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="155"/>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="191"/>
        <source>Security Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="135"/>
        <source>Vpn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="137"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="157"/>
        <source>Cloud Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="159"/>
        <source>Biometrics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="174"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="176"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="193"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="195"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="197"/>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="212"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="214"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="216"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/functionselect.cpp" line="218"/>
        <source>Experienceplan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="46"/>
        <source>Go to monitor settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="47"/>
        <source>Go to defaultapp settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="48"/>
        <source>Go to power settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="49"/>
        <source>Go to autoboot settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="51"/>
        <source>Go to printer settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="52"/>
        <source>Go to projection settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="53"/>
        <source>Go to mouse settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="54"/>
        <source>Go to touchpad settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="56"/>
        <source>Go to keyboard settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="57"/>
        <source>Go to shortcut settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="58"/>
        <source>Go to audio settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="59"/>
        <source>Go to bluetooth settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="61"/>
        <source>Go to background settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="62"/>
        <source>Go to theme settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="63"/>
        <source>Go to screenlock settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="64"/>
        <source>Go to screensaver settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="65"/>
        <source>Go to fonts settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="66"/>
        <source>Go to desktop settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="68"/>
        <source>Go to netconnect settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="69"/>
        <source>Go to vpn settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="70"/>
        <source>Go to proxy settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="72"/>
        <source>Go to userinfo settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="73"/>
        <source>Go to cloudaccount settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="75"/>
        <source>Go to datetime settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="76"/>
        <source>Go to area settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="78"/>
        <source>Go to update settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="79"/>
        <source>Go to backup settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="80"/>
        <source>Go to upgrade settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="82"/>
        <source>Go to notice settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="83"/>
        <source>Go to about settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/utils.cpp" line="84"/>
        <source>Go to search settings page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="229"/>
        <source>Customize Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="505"/>
        <source>Edit Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.cpp" line="177"/>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.cpp" line="214"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1463"/>
        <source>pa_context_subscribe() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1479"/>
        <source>pa_context_client_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1486"/>
        <source>pa_context_get_card_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1493"/>
        <source>pa_context_get_sink_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1500"/>
        <source>pa_context_get_source_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1265"/>
        <source>Failed to initialize stream_restore extension: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1507"/>
        <source>pa_context_get_sink_input_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1514"/>
        <source>pa_context_get_source_output_info_list() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1530"/>
        <source>Connection failed, attempting reconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1282"/>
        <source>pa_ext_stream_restore_read() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="212"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1397"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1472"/>
        <source>pa_context_get_server_info() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1155"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1626"/>
        <source>Sink input callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1175"/>
        <source>Source output callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1215"/>
        <source>Client callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1231"/>
        <source>Server info callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1299"/>
        <source>Failed to initialize device manager extension: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1318"/>
        <source>pa_ext_device_manager_read() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1335"/>
        <source>pa_context_get_sink_info_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1348"/>
        <source>pa_context_get_source_info_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1361"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1374"/>
        <source>pa_context_get_sink_input_info() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1387"/>
        <source>pa_context_get_client_info() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1423"/>
        <source>pa_context_get_card_info_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1550"/>
        <source>Ukui Media Volume Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1093"/>
        <source>Card callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1111"/>
        <source>Sink callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1134"/>
        <source>Source callback failure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="706"/>
        <source>blue-crystal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="708"/>
        <source>dark-sense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="710"/>
        <source>DMZ-Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="712"/>
        <source>DMZ-White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="724"/>
        <source>basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="726"/>
        <source>classical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="728"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="732"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="730"/>
        <source>fashion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changevaliddialog.cpp" line="183"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="332"/>
        <source>min length %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="342"/>
        <source>min digit num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="351"/>
        <source>min upper num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="360"/>
        <source>min lower num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="369"/>
        <source>min other num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="379"/>
        <source>min char class %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="388"/>
        <source>max repeat %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="397"/>
        <source>max class repeat %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="406"/>
        <source>max sequence %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>January</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>February</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>March</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>April</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>June</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>July</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>August</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>September</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>October</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>Novermber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>December</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/backup.cpp" line="135"/>
        <source>system upgrade new backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/backup.cpp" line="136"/>
        <source>system upgrade increment backup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screenlock</name>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="26"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="47"/>
        <source>Screenlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="74"/>
        <source>Screenlock Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="151"/>
        <source>Screenlock Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="205"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="110"/>
        <source>Show picture of screenlock on screenlogin</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Show picture of screenlock on screenlogin</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="277"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="112"/>
        <source>Lock screen when screensaver boot</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Lock screen when screensaver boot</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="349"/>
        <source>Lock screen delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="399"/>
        <source>Select screenlock background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="468"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="116"/>
        <source>Browser online wp</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Browser local wp</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="449"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="114"/>
        <source>Browser local wp</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screenlock/Browser local wp</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="136"/>
        <source>1m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="136"/>
        <source>5m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="136"/>
        <source>10m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="136"/>
        <source>30m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="136"/>
        <source>45m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="137"/>
        <source>1h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="137"/>
        <source>1.5h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="137"/>
        <source>3h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="442"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="442"/>
        <source>allFiles(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="484"/>
        <source>select custom wallpaper file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="485"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="486"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="487"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="488"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="489"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screensaver</name>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="59"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="90"/>
        <source>Screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="399"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="178"/>
        <source>Idle time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screensaver/Idle time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="481"/>
        <source>Lock screen when activating screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="233"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="176"/>
        <source>Screensaver program</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screensaver/Screensaver program</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="164"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="909"/>
        <source>Show rest time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/screensaver/Show rest time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="205"/>
        <source>UKUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="206"/>
        <source>Blank_Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="217"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="754"/>
        <source>5min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="755"/>
        <source>10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="756"/>
        <source>30min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="233"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="655"/>
        <source>Screensaver source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="661"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="711"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="669"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp *.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="710"/>
        <source>select custom screensaver dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="712"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="713"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="714"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="715"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="749"/>
        <source>Switching time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="753"/>
        <source>1min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="796"/>
        <source>Random switching</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="837"/>
        <source>Display text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="847"/>
        <source>Enter text, up to 30 characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="925"/>
        <source>Text position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="930"/>
        <source>Centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="931"/>
        <source>Randow(Bubble text)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Search</name>
    <message>
        <location filename="../../../plugins/messages-task/search/search.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="7"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="111"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="122"/>
        <source>Create Index</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/search/Create Index</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="113"/>
        <source>Creating index can help you getting results quickly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="133"/>
        <source>Block Folders</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/search/Block Folders</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="136"/>
        <source>Following folders will not be searched. You can set it by adding and removing folders.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="164"/>
        <source>Choose folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="178"/>
        <source>Web Engine</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/search/Web Engine</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="179"/>
        <source>Default web searching engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="183"/>
        <source>baidu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="184"/>
        <source>sougou</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="185"/>
        <source>360</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="314"/>
        <source>delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="352"/>
        <source>Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="353"/>
        <source>select blocked folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="354"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="355"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="356"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="357"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="358"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="374"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="378"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="382"/>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="386"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="374"/>
        <source>Add blocked folder failed, choosen path is empty!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="378"/>
        <source>Add blocked folder failed, it is not in home path!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="382"/>
        <source>Add blocked folder failed, its parent dir is exist!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/search/search.cpp" line="386"/>
        <source>Add blocked folder failed, it has been already blocked!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityCenter</name>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/securitycenter.cpp" line="15"/>
        <source>Security Center</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShareMain</name>
    <message>
        <location filename="../../../plugins/network/vino/sharemain.cpp" line="50"/>
        <source>Share</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vino/Share</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/sharemain.cpp" line="59"/>
        <source>Allow others to view your desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/sharemain.cpp" line="74"/>
        <source>Allow connection to control screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/sharemain.cpp" line="83"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vino/Security</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/sharemain.cpp" line="92"/>
        <source>You must confirm every visit for this machine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vino/sharemain.cpp" line="107"/>
        <source>Require user to enter this password: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Shortcut</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.ui" line="47"/>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="152"/>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="166"/>
        <source>System Shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/shortcut/System Shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.ui" line="83"/>
        <source>Custom Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="75"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="154"/>
        <source>Customize Shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/shortcut/Customize Shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="193"/>
        <source>Add custom shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/shortcut/Add custom shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="483"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="479"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SyncDialog</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="34"/>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="35"/>
        <source>Do not</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="60"/>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="101"/>
        <source>Last sync at %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.cpp" line="100"/>
        <source>Sync now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Wallpaper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>ScreenSaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Avatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="44"/>
        <source>Quick Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>Themes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>TouchPad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>KeyBoard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="45"/>
        <source>ShortCut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Date/Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Default Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="46"/>
        <source>Peony</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Weather</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/networkaccount/syncdialog.h" line="47"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabWid</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="57"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="119"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="133"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="138"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="167"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="203"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="441"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="471"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="819"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="919"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1089"/>
        <source>Check Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="59"/>
        <source>initializing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="950"/>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="953"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="960"/>
        <source>Please back up the system before all updates to avoid unnecessary losses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="961"/>
        <source>Prompt information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="221"/>
        <source>Update now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="222"/>
        <source>Cancel update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="229"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="371"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1122"/>
        <source>Being updated...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="126"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="242"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="380"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="845"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="946"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1078"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1126"/>
        <source>UpdateAll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="254"/>
        <source>The backup restore partition could not be found. The system will not be backed up in this update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="258"/>
        <source>Kylin backup restore tool is doing other operations, please update later.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="261"/>
        <source>The source manager configuration file is abnormal, the system temporarily unable to update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="264"/>
        <source>Backup already, no need to backup again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="278"/>
        <source>Kylin backup restore tool does not exist, this update will not backup the system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="337"/>
        <source>Backup complete.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="272"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1156"/>
        <source>Start backup,getting progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1163"/>
        <source>Failed to write configuration file, this update will not back up the system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1167"/>
        <source>Insufficient backup space, this update will not backup your system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1171"/>
        <source>Kylin backup restore tool could not find the UUID, this update will not backup the system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="352"/>
        <source>Backup interrupted, stop updating!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="176"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="292"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="315"/>
        <source>Downloading and installing updates...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="155"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="826"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="871"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1102"/>
        <source>No Information!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="205"/>
        <source>Software source server connection timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="293"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="965"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="340"/>
        <source>System is backing up...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="356"/>
        <source>Backup finished!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="360"/>
        <source>Kylin backup restore tool exception:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="360"/>
        <source>There will be no backup in this update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="433"/>
        <source>Getting update list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="438"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="473"/>
        <source>Software source update failed: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="492"/>
        <source>Update software source :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="519"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="542"/>
        <source>View history</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="589"/>
        <source>Update Settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/upgrade/Update Settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="600"/>
        <source>Allowed to renewable notice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="610"/>
        <source>Backup current system before updates all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="659"/>
        <source>Download Limit(Kb/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="664"/>
        <source>It will be avaliable in the next download.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="963"/>
        <source>Only Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="964"/>
        <source>Back And Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="154"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="326"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="821"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1091"/>
        <source>Your system is the latest!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="241"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="848"/>
        <source>Updatable app detected on your system!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="700"/>
        <source>Automatically download and install updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="702"/>
        <source>After it is turned on, the system will automatically download and install updates when there is an available network and available backup and restore partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="777"/>
        <source>Ready to install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="165"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="836"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="881"/>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1112"/>
        <source>Last refresh:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="882"/>
        <source>Last Checked:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="914"/>
        <source>trying to reconnect </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="914"/>
        <source> times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="934"/>
        <source>Updating the software source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1098"/>
        <source>Part of the update failed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1137"/>
        <source>An important update is in progress, please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1174"/>
        <source>The backup restore partition is abnormal. You may not have a backup restore partition.For more details,see /var/log/backup.log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/tabwidget.cpp" line="1181"/>
        <source>Calculating Capacity...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Theme</name>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="76"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="157"/>
        <source>Theme Mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Theme Mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="342"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="159"/>
        <source>Icon theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Icon theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="415"/>
        <source>Control theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="490"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="161"/>
        <source>Cursor theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Cursor theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="563"/>
        <source>Effect setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="642"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="163"/>
        <source>Performance mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Performance mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="714"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="165"/>
        <source>Transparency</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Transparency</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="829"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="167"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/theme/Reset to default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="112"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="240"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="241"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="242"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeZoneChooser</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="34"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="35"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="45"/>
        <source>Change time zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="71"/>
        <source>Input what you are looking for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="95"/>
        <source>Change Timezone</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TouchScreen</name>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="14"/>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="32"/>
        <location filename="../../../plugins/system/touchscreen/touchscreen.cpp" line="12"/>
        <source>TouchScreen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="134"/>
        <source>touch id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="236"/>
        <source>map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="258"/>
        <source>calibration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="285"/>
        <source>No touch screen found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="202"/>
        <source>input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="69"/>
        <source>Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/touchscreen.ui" line="209"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Touchpad</name>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="41"/>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="86"/>
        <source>Touchpad Settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchpad/Touchpad Settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="177"/>
        <source>Enabled touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="246"/>
        <source>Disable touchpad while typing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="315"/>
        <source>Enable mouse clicks with touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="108"/>
        <source> Mouse to disable  touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="393"/>
        <source>Scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.ui" line="426"/>
        <source>No touchpad found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="56"/>
        <source>Touchpad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="137"/>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="141"/>
        <source>Disable rolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="138"/>
        <source>Edge scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="139"/>
        <source>Two-finger scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="142"/>
        <source>Vertical edge scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="143"/>
        <source>Horizontal edge scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="144"/>
        <source>Vertical two-finger scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="145"/>
        <source>Horizontal two-finger scrolling</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrialDialog</name>
    <message>
        <location filename="../../../plugins/messages-task/about/trialdialog.cpp" line="12"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/trialdialog.cpp" line="37"/>
        <source>Yinhe Kylin OS(Trail Version) Disclaimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/trialdialog.cpp" line="46"/>
        <source>Dear customer:
    Thank you for trying Yinhe Kylin OS(trail version)! This version is free for users who only try out, no commercial purpose is permitted. The trail period lasts one year and it starts from the ex-warehouse time of the OS. No after-sales service is provided during the trail stage. If any security problems occurred when user put important files or do any commercial usage in system, all consequences are taken by users. Kylin software Co., Ltd. take no legal risk in trail version.
    During trail stage,if you want any technology surpport or activate the system, please buy“Yinhe Kylin Operating System”official version or authorization by contacting 400-089-1870.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/trialdialog.cpp" line="54"/>
        <source>Kylin software Co., Ltd.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/messages-task/about/trialdialog.cpp" line="62"/>
        <source>www.Kylinos.cn</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkccAbout</name>
    <message>
        <location filename="../../ukccabout.cpp" line="60"/>
        <location filename="../../ukccabout.cpp" line="82"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="89"/>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="96"/>
        <source>The control panel provides a friendly graphical user interface to manage common configuration items of the operating system. System configuration provides system, equipment, personalization, network, account, time and date, account, time and date, update, notification and operation module operations. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="104"/>
        <source>Service and Support:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkmediaInputWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="67"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="70"/>
        <source>Input Device:</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Input Device</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="73"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Volume</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_input_widget.cpp" line="78"/>
        <source>Input Level</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Input Level</extra-contents_path>
    </message>
</context>
<context>
    <name>UkmediaOutputWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="88"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="91"/>
        <source>Output Device:</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Output Device</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="94"/>
        <source>Master Volume</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Master Volume</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="99"/>
        <source>Balance</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Balance</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="100"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_output_widget.cpp" line="102"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkmediaSoundEffectsWidget</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="54"/>
        <source>System Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="57"/>
        <source>Sound Theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Sound Theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="60"/>
        <source>Alert Sound</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Alert Sound</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="63"/>
        <source>Alert Volume</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/audio/Alert Volume</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="86"/>
        <source>Logout Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="81"/>
        <source>Beep Switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="82"/>
        <source>Poweroff Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="83"/>
        <source>Startup Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="84"/>
        <source>Wakeup Music</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_sound_effects_widget.cpp" line="85"/>
        <source>Volume Change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkmediaVolumeControl</name>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="67"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="92"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="96"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="110"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="136"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="162"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="242"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="246"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="258"/>
        <source>pa_context_set_sink_volume_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="131"/>
        <source>pa_context_set_source_mute_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="275"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="279"/>
        <source>pa_context_set_source_output_volume() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="291"/>
        <source>pa_context_set_source_output_mute() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="303"/>
        <source>pa_context_set_card_profile_by_index() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="317"/>
        <source>pa_context_set_default_sink() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="331"/>
        <source>pa_context_set_default_source() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="345"/>
        <source>pa_context_set_sink_port_by_name() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="359"/>
        <source>pa_context_set_source_port_by_name() failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="388"/>
        <source> (plugged in)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="392"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="506"/>
        <source> (unavailable)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="394"/>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="503"/>
        <source> (unplugged)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="602"/>
        <source>Failed to read data from stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="647"/>
        <source>Peak detect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="648"/>
        <source>Failed to create monitoring stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="663"/>
        <source>Failed to connect monitoring stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="762"/>
        <source>Ignoring sink-input due to it being designated as an event and thus handled by the Event widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/audio/ukmedia_volume_control.cpp" line="1059"/>
        <source>Establishing connection to PulseAudio. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UnifiedOutputConfig</name>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="76"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="105"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="110"/>
        <source>arrow-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="111"/>
        <source>90° arrow-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="112"/>
        <source>arrow-down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="113"/>
        <source>90° arrow-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="142"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="147"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="300"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="173"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="270"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="276"/>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="313"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Update</name>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="26"/>
        <location filename="../../../plugins/security-updates/update/update.cpp" line="33"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="44"/>
        <location filename="../../../plugins/security-updates/update/update.cpp" line="69"/>
        <source>System Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="94"/>
        <source>Last check time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/update/update.ui" line="139"/>
        <location filename="../../../plugins/security-updates/update/update.cpp" line="72"/>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/update/Check for updates</extra-contents_path>
    </message>
</context>
<context>
    <name>UpdateDbus</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatedbus.cpp" line="103"/>
        <source>System-Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatedbus.cpp" line="106"/>
        <source>ukui-control-center-update</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateLog</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatelog.cpp" line="17"/>
        <source>Update log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateSource</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/updatesource.cpp" line="80"/>
        <source>Connection failed, please reconnect!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Upgrade</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/upgrade.cpp" line="7"/>
        <source>Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserInfo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="41"/>
        <source>Current User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="819"/>
        <source>Change pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="806"/>
        <source>Change type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="285"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="153"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Password</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="304"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="155"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Type</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="323"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="161"/>
        <source>Group</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Group</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="389"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="157"/>
        <source>Login no passwd</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Login no passwd</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="159"/>
        <source>enable autoLogin</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/enable autoLogin</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="467"/>
        <source>Automatic login at boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="545"/>
        <source>Currently in Live mode, please create a new user and log out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="608"/>
        <source>Biometric Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="628"/>
        <source>advanced settings </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="735"/>
        <source>enable biometrics </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="804"/>
        <source>types of biometric password </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="883"/>
        <source>biometric device </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="1020"/>
        <source>Other Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="70"/>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="167"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="169"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="171"/>
        <source>root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="461"/>
        <source>Add new user</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/userinfo/Add new user</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="527"/>
        <source>Pwd Changed Succes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="837"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="969"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="969"/>
        <source>The user is logged in, please delete the user after logging out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1342"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1343"/>
        <source>The system only allows one user to log in automatically.After it is turned on, the automatic login of other users will be turned off.Is it turned on?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1346"/>
        <source>Trun on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1347"/>
        <source>Close on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1417"/>
        <source>Add biometric feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1730"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1935"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1949"/>
        <source>Verify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1969"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vino</name>
    <message>
        <location filename="../../../plugins/network/vino/vino.cpp" line="24"/>
        <source>Vino</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vpn</name>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.ui" line="53"/>
        <source>Add Vpn Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.cpp" line="28"/>
        <source>Vpn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.cpp" line="91"/>
        <source>Add vpn connect</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/vpn/Add vpn connect</extra-contents_path>
    </message>
</context>
<context>
    <name>Wallpaper</name>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="103"/>
        <source>Desktop Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="308"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="110"/>
        <source>Select from</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Select from</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="480"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="114"/>
        <source>Browser online wp</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Browser online wp</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="499"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="112"/>
        <source>Browser local wp</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Browser local wp</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="518"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="116"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/wallpaper/Reset to default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="49"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="131"/>
        <source>picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="131"/>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="162"/>
        <source>Custom color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="477"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="477"/>
        <source>allFiles(*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="517"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="559"/>
        <source>select custom wallpaper file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="518"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="560"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="519"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="561"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="520"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="562"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="521"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="563"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="522"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="564"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../../../plugins/system/touchscreen/widget.cpp" line="81"/>
        <source>touch id</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchscreen/touch id</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/widget.cpp" line="83"/>
        <source>Monitor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/touchscreen/monitor</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/touchscreen/widget.cpp" line="461"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="558"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="559"/>
        <source>Some applications need to be logouted to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="627"/>
        <source>unify output</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/unify output</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="631"/>
        <source>night mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/night mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="639"/>
        <source>Theme follow night mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="660"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="661"/>
        <source>After modifying the resolution or refresh rate, due to compatibility issues between the display device and the graphics card, the display may be abnormal or unable to display
the settings will be saved after 14 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="665"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="666"/>
        <source>Not Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="675"/>
        <source>After modifying the resolution or refresh rate, due to compatibility issues between the display device and the graphics card, the display may be abnormal or unable to display 
the settings will be saved after %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1883"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1890"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="545"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/monitor</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="547"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/screen zoom</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1108"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1270"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1277"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1270"/>
        <source>please insure at least one output!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1109"/>
        <source>Open time should be earlier than close time!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1278"/>
        <source>Sorry, your configuration could not be applied.
Common reasons are that the overall screen size is too big, or you enabled more displays than supported by your GPU.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addShortcutDialog</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="103"/>
        <source>Exec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="154"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="174"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="214"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="349"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="356"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="419"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="241"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="438"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="63"/>
        <source>Add custom shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="77"/>
        <source>Please enter a shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="233"/>
        <source>Desktop files(*.desktop)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="240"/>
        <source>select desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="262"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="281"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="292"/>
        <source>Invalid application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="264"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="277"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="288"/>
        <source>Shortcut conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="266"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="279"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="290"/>
        <source>Invalid shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="268"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="275"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="294"/>
        <source>Name repetition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="300"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>changtimedialog</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="115"/>
        <source>current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="200"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="321"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="398"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="472"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="574"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="593"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ksc_main_page_widget</name>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_main_page_widget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_main_page_widget.ui" line="158"/>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_main_page_widget.cpp" line="45"/>
        <source>Run Security Center</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/securitycenter/Run Security Center</extra-contents_path>
    </message>
</context>
<context>
    <name>ksc_module_func_widget</name>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.ui" line="26"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.ui" line="182"/>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.ui" line="198"/>
        <location filename="../../../plugins/security-updates/securitycenter/ksc_module_func_widget.cpp" line="20"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>m_updatelog</name>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="614"/>
        <source>History Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="113"/>
        <source>Update Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="57"/>
        <source>No content.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="534"/>
        <location filename="../../../plugins/security-updates/upgrade/src/m_updatelog.cpp" line="567"/>
        <source>Search content</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>networkaccount</name>
    <message>
        <location filename="../../../plugins/account/networkaccount/networkaccount.cpp" line="24"/>
        <source>Cloud Account</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
