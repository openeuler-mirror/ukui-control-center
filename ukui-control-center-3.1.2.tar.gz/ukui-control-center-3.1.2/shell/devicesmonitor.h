#ifndef DEVICESMONITOR_H
#define DEVICESMONITOR_H

bool isExistTouchScreen();
bool isfindSynaptics();

#endif // DEVICESMONITOR_H
