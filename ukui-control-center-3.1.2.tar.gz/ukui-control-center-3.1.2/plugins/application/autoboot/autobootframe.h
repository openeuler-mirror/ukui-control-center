#ifndef AUTOBOOTFRAME_H
#define AUTOBOOTFRAME_H


class AutobootFrame : public QFrame
{
    Q_OBJECT
public:
    AutobootFrame();
};

#endif // AUTOBOOTFRAME_H
