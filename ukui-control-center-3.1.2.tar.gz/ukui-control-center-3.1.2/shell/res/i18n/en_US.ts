<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="514"/>
        <source>System Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="565"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/version</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="441"/>
        <source>Copyright © 2009-2021 KylinSoft. All rights reserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="567"/>
        <source>Kernel</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/Kernel</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="569"/>
        <source>CPU</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/CPU</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="571"/>
        <source>Memory</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/Memory</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="517"/>
        <location filename="../../../plugins/system/about/about.cpp" line="905"/>
        <source>Disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="573"/>
        <source>Desktop</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/Desktop</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="575"/>
        <source>User</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/User</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="578"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="64"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="515"/>
        <source>Support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="187"/>
        <location filename="../../../plugins/system/about/about.cpp" line="516"/>
        <source>Version Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="577"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/About/Status</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="579"/>
        <source>DateRes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="519"/>
        <source>Wechat code scanning obtains HP professional technical support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="520"/>
        <source>See more about Kylin Tianqi edu platform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="451"/>
        <source>&lt;&lt;Protocol&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="207"/>
        <source>InterVersion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="249"/>
        <source>HostName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="389"/>
        <source>Privacy and agreement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="399"/>
        <source>Send optional diagnostic data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="401"/>
        <source>By sending us diagnostic data, improve the system experience and solve your problems faster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="452"/>
        <source>and</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="453"/>
        <source>&lt;&lt;Privacy&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="541"/>
        <source>Learn more HP user manual&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="551"/>
        <source>See user manual&gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="641"/>
        <location filename="../../../plugins/system/about/about.cpp" line="647"/>
        <source>Active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="643"/>
        <source>Not activated (trial period)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="645"/>
        <source>Trial expiration time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="652"/>
        <source>Activated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="978"/>
        <source>expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="983"/>
        <source>Extend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="1119"/>
        <source>The system needs to be restarted to set the HostName, whether to reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="1120"/>
        <source>Reboot Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="1121"/>
        <source>Reboot Later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="639"/>
        <source>Inactivated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/about.cpp" line="898"/>
        <location filename="../../../plugins/system/about/about.cpp" line="907"/>
        <location filename="../../../plugins/system/about/about.cpp" line="1253"/>
        <source>avaliable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddAutoBoot</name>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="220"/>
        <source>Add autoboot program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="224"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="166"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="221"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="167"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="222"/>
        <source>Exec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="168"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="223"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="225"/>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="245"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="226"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="236"/>
        <source>Desktop files(*.desktop)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="243"/>
        <source>select autoboot desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="244"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="291"/>
        <source>desktop file not allowed add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/addautoboot.cpp" line="340"/>
        <source>desktop file not exist</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddBtn</name>
    <message>
        <location filename="../../../commonComponent/AddBtn/addbtn.cpp" line="21"/>
        <location filename="../../../libukcc/widgets/AddBtn/addbtn.cpp" line="19"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AptProxyDialog</name>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="25"/>
        <source>Set Apt Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="42"/>
        <source>Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="60"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="81"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/aptproxydialog.cpp" line="85"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Area</name>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="26"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="42"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="156"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="353"/>
        <source>Current Region</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/Current Region</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="350"/>
        <source>First Day Of The Week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="264"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="355"/>
        <source>Calendar</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/Calendar</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="59"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="159"/>
        <source>Language Format</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/Regional Format</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="433"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="359"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/Date</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="516"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="361"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="555"/>
        <location filename="../../../plugins/time-language/area/area.cpp" line="161"/>
        <source>System Language</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/system language</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.ui" line="589"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="366"/>
        <source>lunar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="369"/>
        <source>monday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="217"/>
        <source>US</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="218"/>
        <source>CN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="165"/>
        <source>Language for system windows,menus and web pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="357"/>
        <source>First Day Of Week</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Area/First Day Of Week</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="363"/>
        <source>solar calendar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="370"/>
        <source>sunday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="381"/>
        <source>12 Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="382"/>
        <source>24 Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="491"/>
        <source>Modify the current region need to logout to take effect, whether to logout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="492"/>
        <source>Logout later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="493"/>
        <source>Logout now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="495"/>
        <source>Modify the first language need to reboot to take effect, whether to reboot?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="496"/>
        <source>Reboot later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/area/area.cpp" line="497"/>
        <source>Reboot now</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutoBoot</name>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="560"/>
        <source>Autoboot Settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Autoboot Settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="66"/>
        <source>Auto Boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="226"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/autoboot/autoboot.cpp" line="549"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/autoboot/Add</extra-contents_path>
    </message>
</context>
<context>
    <name>Backup</name>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="53"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="40"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="109"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="69"/>
        <source>Back up your files to other drives, and when the original files are lost, damaged, or deleted, 
you can restore them to ensure the integrity of your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="113"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="157"/>
        <source>Begin backup</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Backup/Begin backup</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="157"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="133"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="173"/>
        <source>View a list of backed-upfiles to backed up files to the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.ui" line="213"/>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="159"/>
        <source>Begin restore</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Backup/Begin restore</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/backup.ui" line="144"/>
        <source>All data stored on the computer will be permanently erased,and the system will revert to 
                                its original factory state when this operation is completed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/backup.ui" line="213"/>
        <location filename="../../../plugins/system/backup_intel/backup.cpp" line="76"/>
        <source>Clear and restore</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Backup/Clear and restore</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/backup.cpp" line="42"/>
        <source>System Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="111"/>
        <source>Back up your files to other drives and restore them when the source files are lost, damaged, or deleted to ensure the integrity of the system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="135"/>
        <source>View the backup list and restore the backup file to the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/security-updates/backup/backup.cpp" line="155"/>
        <source>Backup and Restore</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrightnessFrame</name>
    <message>
        <location filename="../../../plugins/system/display/brightnessFrame.cpp" line="37"/>
        <source>Failed to get the brightness information of this monitor</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeFaceIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="85"/>
        <source>Change User Face</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="277"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="385"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="470"/>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="357"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.ui" line="505"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="352"/>
        <source>select custom face file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="353"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="354"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="355"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="356"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="371"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changefaceinteldialog.cpp" line="371"/>
        <source>The avatar is larger than 2M, please choose again</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="79"/>
        <source>User Group Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.ui" line="194"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="244"/>
        <source>User group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="291"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="334"/>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="342"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="334"/>
        <source>Invalid Id!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="337"/>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="345"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changegroupdialog.cpp" line="342"/>
        <source>Invalid Group Name!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeGroupIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.ui" line="119"/>
        <source>User Group Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.ui" line="149"/>
        <source>User groups available in the system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changegroupinteldialog.cpp" line="119"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePhoneIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="77"/>
        <source>changephone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="190"/>
        <source>Please input old phone num</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="242"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="429"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="452"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="366"/>
        <source>GetVerifyCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.ui" line="586"/>
        <source>submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="53"/>
        <source>Change Phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="91"/>
        <source>Phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="92"/>
        <source>SMS verification code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="124"/>
        <source>Please input old phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="125"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="128"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="251"/>
        <source>Please enter new mobile number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="129"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="252"/>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="145"/>
        <source>changed success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="146"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="322"/>
        <source>You have successfully modified your phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="197"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="221"/>
        <source>Recapture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="211"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="271"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="306"/>
        <source>Network connection failure, please check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="231"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="256"/>
        <source>GetCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="264"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="296"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="325"/>
        <source>Phone is lock,try again in an hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="267"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="299"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="328"/>
        <source>Phone code is wrong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="274"/>
        <source>Current login expired,using wechat code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="277"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="309"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="335"/>
        <source>Unknown error, please try again later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="284"/>
        <source>Phone can not same</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="293"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="321"/>
        <source>finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="303"/>
        <location filename="../../../plugins/account/userinfo_intel/changephoneinteldialog.cpp" line="332"/>
        <source>Phone number already in used!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePinIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepininteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepininteldialog.ui" line="74"/>
        <source>Change Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangePwdIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.ui" line="119"/>
        <source>Change Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.ui" line="603"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.ui" line="643"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="186"/>
        <source>General Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="198"/>
        <source>Old Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="199"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="575"/>
        <source>New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="200"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="576"/>
        <source>New Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="332"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="341"/>
        <source>Please set different pwd!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="349"/>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="560"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="414"/>
        <source>Old pwd is wrong!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="416"/>
        <source>New pwd is too similar with old pwd!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="421"/>
        <source>Check old pwd failed because of unknown reason!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="537"/>
        <source>Password length needs to more than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="539"/>
        <source>Password length needs to less than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changepwdinteldialog.cpp" line="547"/>
        <source>Password cannot be made up entirely by Numbers!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeTypeIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="108"/>
        <source>Change Account Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="409"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="422"/>
        <source>Standard users can use most software, but cannot install software and change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="543"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="556"/>
        <source>Administrators can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="579"/>
        <source>Make sure that there is at least one administrator on the computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="619"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changetypeinteldialog.ui" line="654"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserLogo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="129"/>
        <source>System Logos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="138"/>
        <source>Local Logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="147"/>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="283"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="149"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="278"/>
        <source>select custom face file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="279"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="280"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="281"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="282"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="298"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserlogo.cpp" line="299"/>
        <source>The avatar is larger than 1M, please choose again</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserNickname</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="33"/>
        <source>Set Nickname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="56"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="72"/>
        <source>NickName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="76"/>
        <source>nickName already in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="149"/>
        <source>nickName length must less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="112"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusernickname.cpp" line="115"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserPwd</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="100"/>
        <source>Change password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="105"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="109"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="451"/>
        <source>Current Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="135"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="139"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="452"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="460"/>
        <source>New Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="165"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="169"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="453"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="461"/>
        <source>Sure Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="224"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="262"/>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="525"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="345"/>
        <source>Authentication failed, input authtok again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeuserpwd.cpp" line="486"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeUserType</name>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="25"/>
        <source>UserType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="70"/>
        <source>Ensure that must have admin on system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="80"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="82"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="84"/>
        <source>Users can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="86"/>
        <source>Users cannot change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="137"/>
        <source>Note: Effective After Logout!!!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="148"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/changeusertype.cpp" line="151"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangeValidIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="180"/>
        <source>Password Validity Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="312"/>
        <source>Current passwd validity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="394"/>
        <source>Adjust date to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="493"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.ui" line="500"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChangtimeDialog</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="161"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="162"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="163"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="164"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="86"/>
        <source>选择自定义颜色</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="236"/>
        <source>HEX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="250"/>
        <source>RGB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="411"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.ui" line="430"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/colordialog.cpp" line="95"/>
        <source>Custom color</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="266"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="288"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="50"/>
        <source>Add New Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="77"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="124"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.ui" line="172"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/creategroupdialog.cpp" line="206"/>
        <source>Add user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateGroupIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="115"/>
        <source>Add New Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="144"/>
        <source>Group Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="182"/>
        <source>Group Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="234"/>
        <source>Group Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="344"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/creategroupinteldialog.ui" line="363"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateUserIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="117"/>
        <source>Add New Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="458"/>
        <source>Account Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="550"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="563"/>
        <source>Standard users can use most software, but cannot install the software and 
change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="666"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="679"/>
        <source>Administrators can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="728"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.ui" line="760"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="150"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="151"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="152"/>
        <source>Password Identify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="307"/>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="430"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="417"/>
        <source>Password length needs to more than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="419"/>
        <source>Password length needs to less than %1 character!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="526"/>
        <source>The user name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="528"/>
        <source>The first character must be lowercase letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="531"/>
        <source>User name can not contain capital letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="545"/>
        <source>The user name is already in use, please use a different one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="550"/>
        <source>User name length need to less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="552"/>
        <source>The user name can only be composed of letters, numbers and underline!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/createuserinteldialog.cpp" line="557"/>
        <source>The username is configured, please change the username</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CreateUserNew</name>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="27"/>
        <source>CreateUserNew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="48"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="51"/>
        <source>NickName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="54"/>
        <source>Pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="57"/>
        <source>SurePwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="114"/>
        <source>Select Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="123"/>
        <source>Administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="126"/>
        <source>Users can make any changes they need</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="128"/>
        <source>Standard User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="131"/>
        <source>Users cannot change system settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="203"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="205"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="250"/>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="507"/>
        <source>Inconsistency with pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="377"/>
        <source>The nick name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="379"/>
        <source>nickName already in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="381"/>
        <source>nickName length must less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="405"/>
        <source>The user name cannot be empty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="407"/>
        <source>Must be begin with lower letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="410"/>
        <source>Can not contain capital letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="432"/>
        <source>Name already in use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="434"/>
        <source>Name corresponds to group already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="439"/>
        <source>Name length must less than %1 letters!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="441"/>
        <source>Can only contain letters,digits,underline!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="445"/>
        <source>Username&apos;s folder exists, change another one</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/createusernew.cpp" line="477"/>
        <source>Contains illegal characters!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomLineEdit</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/customlineedit.cpp" line="28"/>
        <source>New Shortcut...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DateTime</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="26"/>
        <source>DateTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="65"/>
        <source>current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="321"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="244"/>
        <source>Change timezone</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Change time zone</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="444"/>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="620"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="481"/>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="510"/>
        <source>RadioButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="712"/>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="744"/>
        <source>:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.ui" line="952"/>
        <source>titleLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="81"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="156"/>
        <source>Other Timezone</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Other Timezone</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="170"/>
        <source>24-hour clock</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/24-hour clock</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="573"/>
        <source>Add Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="255"/>
        <source>Sync Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Sync Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="172"/>
        <source>Set Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Set Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="200"/>
        <source>Set Date Manually</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Set Date Manually</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="257"/>
        <source>Manual Time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Manual Time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="396"/>
        <source>Sync Server</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Date/Sync Server</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="398"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="400"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="410"/>
        <source>Server Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="415"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="416"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="563"/>
        <source>change time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="575"/>
        <source>Change Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="774"/>
        <source>  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="775"/>
        <location filename="../../../plugins/time-language/datetime/datetime.cpp" line="784"/>
        <source>Sync failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultApp</name>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="37"/>
        <source>Default App</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="61"/>
        <source>No program available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="305"/>
        <source>Browser</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Defaultapp/Browser</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="307"/>
        <source>Mail</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Defaultapp/Mail</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="309"/>
        <source>Image Viewer</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Defaultapp/Image Viewer</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="311"/>
        <source>Audio Player</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Defaultapp/Audio Player</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="313"/>
        <source>Video Player</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Defaultapp/Video Player</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="315"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Defaultapp/Text Editor</extra-contents_path>
    </message>
</context>
<context>
    <name>DefaultAppWindow</name>
    <message>
        <location filename="../../../plugins/application/defaultapp/defaultapp.cpp" line="303"/>
        <source>Select Default Application</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineGroupItem</name>
    <message>
        <location filename="../../../plugins/account/userinfo/definegroupitem.cpp" line="53"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/definegroupitem.cpp" line="62"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineGroupItemIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/definegroupitemintel.cpp" line="53"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/definegroupitemintel.cpp" line="62"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefineShortcutItem</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/defineshortcutitem.cpp" line="58"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="68"/>
        <source>Are you sure to delete the group:   </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="73"/>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="74"/>
        <source>which will make some file components in the file system invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="81"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="87"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/delgroupdialog.cpp" line="53"/>
        <source>Delete user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelGroupIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="38"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="82"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="104"/>
        <source>RemoveFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/delgroupinteldialog.ui" line="145"/>
        <source>Remind</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelUserIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.ui" line="90"/>
        <source>   Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.ui" line="216"/>
        <source>Define</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.ui" line="241"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/deluserinteldialog.cpp" line="54"/>
        <source>Delete the user, belonging to the user&apos;s desktop documents, favorites, music, pictures and video folder will be deleted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeleteUserExists</name>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="59"/>
        <source>Delete user &apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="60"/>
        <source>&apos;? And:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="85"/>
        <source>Keep user&apos;s home folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="119"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="121"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/deleteuserexists.cpp" line="87"/>
        <source>Delete whole data belong user</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DigitalAuthIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="52"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="287"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="312"/>
        <source>Enter Old Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="76"/>
        <source>Forget Password?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="97"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="152"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="223"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="253"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="263"/>
        <source>Input New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="142"/>
        <source>Input Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="230"/>
        <source>The password input is error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="244"/>
        <source>Confirm New Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="250"/>
        <source>The password input is inconsistent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="260"/>
        <source>New password can not be consistent of old password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="284"/>
        <location filename="../../../plugins/account/userinfo_intel/digitalauthinteldialog.cpp" line="309"/>
        <source>Password Change Failed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DigitalPhoneIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalphoneinteldialog.cpp" line="52"/>
        <source>Please Enter Edu OS Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/digitalphoneinteldialog.cpp" line="163"/>
        <source>The password input is error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayPerformanceDialog</name>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="26"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="214"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="214"/>
        <source>Display Advanced Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="297"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="297"/>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="376"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="376"/>
        <source>Applicable to machine with discrete graphics, which can accelerate the rendering of 3D graphics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="392"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="392"/>
        <source>(Note: not support connect graphical with xmanager on windows.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="462"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="462"/>
        <source>Compatible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="538"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="538"/>
        <source>Applicable to machine with integrated graphics,  there is no 3D graphics acceleration. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="554"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="554"/>
        <source>(Note: need connect graphical with xmanager on windows, use this option.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="624"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="624"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="700"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="700"/>
        <source>Auto select according to environment, delay the login time (about 0.5 sec).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="721"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="721"/>
        <source>Threshold:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="744"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="744"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="757"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="757"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/displayperformancedialog.ui" line="772"/>
        <location filename="../../../plugins/system/display_hw/displayperformancedialog.ui" line="772"/>
        <source>(Note: select this option to use 3D graphics acceleration and xmanager.)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplaySet</name>
    <message>
        <location filename="../../../plugins/system/display/display.cpp" line="34"/>
        <location filename="../../../plugins/system/display_hw/display_hw.cpp" line="34"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DisplayWindow</name>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="14"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="32"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="32"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="168"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="139"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="317"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="238"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="409"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="299"/>
        <source>open monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="353"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="214"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="185"/>
        <source>as main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="583"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="537"/>
        <source>follow the sunrise and sunset(17:55-05:04)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="647"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="601"/>
        <source>custom time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="711"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="665"/>
        <source>opening time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="794"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="748"/>
        <source>closing time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="889"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="843"/>
        <source>color temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="896"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="850"/>
        <source>warm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/display.ui" line="919"/>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="873"/>
        <source>cold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/display_hw.ui" line="395"/>
        <source>Mirror Display</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditGroupDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="275"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="297"/>
        <source>Certain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="50"/>
        <source>Edit User Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="77"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="124"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.ui" line="175"/>
        <source>Members</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="223"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="223"/>
        <source>Invalid Id!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="226"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/editgroupdialog.cpp" line="276"/>
        <source>Edit user group</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fonts</name>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="50"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="64"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="146"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="139"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Fonts/Font size</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="258"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="141"/>
        <source>Fonts select</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Fonts/Fonts select</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="409"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/fonts/fonts.ui" line="358"/>
        <location filename="../../../plugins/personalized/fonts/fonts.cpp" line="143"/>
        <source>Mono font</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Fonts/Mono font</extra-contents_path>
    </message>
</context>
<context>
    <name>HostNameDialog</name>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="14"/>
        <source>Set HostName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="43"/>
        <source>HostName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="64"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/hostnamedialog.cpp" line="68"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputPwdDialog</name>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="46"/>
        <source>Set Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="98"/>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="118"/>
        <source>Password can not be blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="78"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="29"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="82"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/inputpwddialog.cpp" line="122"/>
        <source>less than or equal to 8</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbPreviewFrame</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/kbpreviewframe.cpp" line="321"/>
        <source>No preview found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/kbpreviewframe.cpp" line="325"/>
        <source>Unable to open Preview !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbdLayoutManager</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="68"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="144"/>
        <source>L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="222"/>
        <source>Variant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.ui" line="270"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="61"/>
        <source>Add Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="237"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/kbdlayoutmanager.cpp" line="291"/>
        <source>Keyboard Preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyValueConverter</name>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="46"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="49"/>
        <source>Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="55"/>
        <source>Personalized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="52"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="58"/>
        <source>Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="61"/>
        <source>Datetime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="64"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="67"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="70"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../utils/keyvalueconverter.cpp" line="73"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardControl</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardcontrol.cpp" line="24"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardMain</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="39"/>
        <source>Key board settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="50"/>
        <source>Input settings</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Keyboard/Input settings</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="88"/>
        <source>Key repeat</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Keyboard/Key repeat</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="110"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Keyboard/Delay</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="112"/>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="114"/>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="140"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Keyboard/Speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="142"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="144"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="170"/>
        <source>Input test</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Keyboard/Input test</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/keyboardmain.cpp" line="191"/>
        <source>Key tips</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Keyboard/Key tips</extra-contents_path>
    </message>
</context>
<context>
    <name>KeyboardPainter</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="31"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="67"/>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="69"/>
        <source>Keyboard layout levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="67"/>
        <location filename="../../../plugins/devices/keyboard/preview/keyboardpainter.cpp" line="69"/>
        <source>Level %1, %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LayoutManager</name>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="121"/>
        <source>Manager Keyboard Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="234"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="250"/>
        <source>Country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="293"/>
        <source>Variant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="351"/>
        <source>Layout installed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="399"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="431"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/keyboard/layoutmanager.ui" line="450"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../mainwindow.cpp" line="346"/>
        <location filename="../../mainwindow.cpp" line="395"/>
        <location filename="../../mainwindow.cpp" line="864"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="375"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="404"/>
        <source>Main menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="405"/>
        <source>Minimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="406"/>
        <source>Maximize/Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="407"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="470"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="472"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="474"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="977"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="977"/>
        <source>This function has been controlled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBox</name>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="97"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="138"/>
        <source>It takes effect after logging off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="209"/>
        <source>Logout Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.ui" line="228"/>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="30"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="29"/>
        <source>Reboot Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="31"/>
        <source>This cleanup and restore need to be done after the system restarts, whether to restart and restore immediately?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messagebox.cpp" line="34"/>
        <source>System Backup Tips</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBoxDialog</name>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="68"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="152"/>
        <source>You do not have administrator rights!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="162"/>
        <source> Factory Settings cannot be restored!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxdialog.ui" line="247"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBoxPower</name>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="53"/>
        <source>System Recovery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="62"/>
        <source>The battery is low,please connect the power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="64"/>
        <source>Keep the power connection, or the power is more than 25%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="68"/>
        <source>Remind in 30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/backup_intel/messageboxpower.cpp" line="80"/>
        <source>Got it</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MessageBoxPowerIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/messageboxpowerintel.cpp" line="48"/>
        <source>Nothing has been entered, re-enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/messageboxpowerintel.cpp" line="59"/>
        <source>Remind in 30 minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/messageboxpowerintel.cpp" line="71"/>
        <source>Got it</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MouseControl</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mousecontrol.cpp" line="24"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MouseUI</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="93"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="99"/>
        <source>Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="106"/>
        <source>Cursor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="165"/>
        <source>Dominant hand</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Dominant hand</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="167"/>
        <source>Left hand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="168"/>
        <source>Right hand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="193"/>
        <source>Wheel speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Wheel speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="195"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="258"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="391"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="202"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="265"/>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="398"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="224"/>
        <source>Double-click interval time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Double-click interval time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="226"/>
        <source>Short</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="233"/>
        <source>Long</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="256"/>
        <source>Pointer speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Pointer speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="288"/>
        <source>Mouse acceleration</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Mouse acceleration</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="309"/>
        <source>Show pointer position when pressing ctrl</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Show pointer position when pressing ctrl</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="331"/>
        <source>Pointer size</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Pointer size</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="333"/>
        <source>Small(recommend)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="334"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="335"/>
        <source>Large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="367"/>
        <source>Blinking cursor in text area</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Blinking cursor in text area</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="389"/>
        <source>Cursor speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Mouse/Cursor speed</extra-contents_path>
    </message>
</context>
<context>
    <name>MyLabel</name>
    <message>
        <location filename="../../../plugins/devices/mouse/mouseui.cpp" line="21"/>
        <source>double-click to test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Notice</name>
    <message>
        <location filename="../../../plugins/system/notice/notice.cpp" line="187"/>
        <source>Notice Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/notice/notice.cpp" line="189"/>
        <source>Get notifications from the app</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/notice/Get notifications from the app</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/notice/notice.cpp" line="39"/>
        <source>Notice</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NumbersButtonIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/numbersbuttonintel.cpp" line="47"/>
        <source>clean</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputConfig</name>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="76"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Display/resolution</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="110"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="122"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Display/orientation</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="128"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="139"/>
        <source>arrow-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="129"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="140"/>
        <source>90° arrow-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="131"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="142"/>
        <source>arrow-down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="130"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="141"/>
        <source>90° arrow-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="145"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="154"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Display/frequency</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="345"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="184"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Display/screen zoom</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/outputconfig.cpp" line="443"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="281"/>
        <location filename="../../../plugins/system/display_hw/outputconfig.cpp" line="288"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PhoneAuthIntelDialog</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="42"/>
        <source>Wechat Auth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="44"/>
        <source>Phone Auth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="71"/>
        <source>Phone number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="75"/>
        <source>SMS verification code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="105"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="331"/>
        <source>GetCode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="115"/>
        <source>Return</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="116"/>
        <source>Commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="204"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="224"/>
        <source>commit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="260"/>
        <source>Mobile number acquisition failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="292"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="323"/>
        <source>Recapture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="315"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="393"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="563"/>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="681"/>
        <source>Network connection failure, please check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="380"/>
        <source>Phone is lock,try again in an hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="386"/>
        <source>Phone code is wrong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="399"/>
        <source>Current login expired,using wechat code!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="405"/>
        <source>Unknown error, please try again later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/phoneauthinteldialog.cpp" line="662"/>
        <source>Please use the correct wechat scan code</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Power</name>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="59"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <location filename="../../../plugins/system/power/power.cpp" line="731"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="542"/>
        <location filename="../../../plugins/system/power/power.cpp" line="543"/>
        <source>Require password when sleep/hibernation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="546"/>
        <location filename="../../../plugins/system/power/power.cpp" line="547"/>
        <source>Password required when waking up the screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="550"/>
        <source>Press the power button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="554"/>
        <location filename="../../../plugins/system/power/power.cpp" line="555"/>
        <source>Time to close display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="558"/>
        <location filename="../../../plugins/system/power/power.cpp" line="559"/>
        <source>Time to sleep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="562"/>
        <location filename="../../../plugins/system/power/power.cpp" line="563"/>
        <source>Notebook cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="566"/>
        <location filename="../../../plugins/system/power/power.cpp" line="567"/>
        <source>Balance (suggest)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="570"/>
        <location filename="../../../plugins/system/power/power.cpp" line="571"/>
        <source>Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="574"/>
        <location filename="../../../plugins/system/power/power.cpp" line="575"/>
        <source>Autobalance energy and performance with available hardware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="578"/>
        <location filename="../../../plugins/system/power/power.cpp" line="579"/>
        <source>Users develop personalized power plans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="582"/>
        <location filename="../../../plugins/system/power/power.cpp" line="583"/>
        <location filename="../../../plugins/system/power/power.cpp" line="587"/>
        <source>Using power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="586"/>
        <source>Using battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="590"/>
        <location filename="../../../plugins/system/power/power.cpp" line="591"/>
        <source> Time to darken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="594"/>
        <location filename="../../../plugins/system/power/power.cpp" line="595"/>
        <source>Battery level is lower than</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="598"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="600"/>
        <location filename="../../../plugins/system/power/power.cpp" line="601"/>
        <source>Low battery notification</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="604"/>
        <source>Automatically run saving mode when low battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="605"/>
        <source>Automatically run saving mode when the low battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="608"/>
        <location filename="../../../plugins/system/power/power.cpp" line="609"/>
        <source>Automatically run saving mode when using battery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="612"/>
        <location filename="../../../plugins/system/power/power.cpp" line="613"/>
        <source>Display remaining charging time and usage time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="670"/>
        <source>General</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Power/General</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="672"/>
        <source>Select Powerplan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Power/Select Powerplan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="674"/>
        <source>Battery saving plan</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Power/Battery saving plan</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="739"/>
        <source>nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="739"/>
        <source>blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <location filename="../../../plugins/system/power/power.cpp" line="739"/>
        <source>suspend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="686"/>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <location filename="../../../plugins/system/power/power.cpp" line="745"/>
        <source>hibernate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <source>interactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="731"/>
        <source>5min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <location filename="../../../plugins/system/power/power.cpp" line="731"/>
        <source>10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>15min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>30min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>1h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="700"/>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>2h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="710"/>
        <source>3h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="720"/>
        <location filename="../../../plugins/system/power/power.cpp" line="725"/>
        <source>Balance Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="720"/>
        <location filename="../../../plugins/system/power/power.cpp" line="725"/>
        <source>Save Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="720"/>
        <location filename="../../../plugins/system/power/power.cpp" line="725"/>
        <source>Performance Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="731"/>
        <source>1min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="731"/>
        <source>20min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/power/power.cpp" line="680"/>
        <location filename="../../../plugins/system/power/power.cpp" line="691"/>
        <location filename="../../../plugins/system/power/power.cpp" line="739"/>
        <source>shutdown</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Printer</name>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="32"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="111"/>
        <source>Printers And Scanners</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/printer/printer.cpp" line="176"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Printer/Add</extra-contents_path>
    </message>
</context>
<context>
    <name>PrivacyDialog</name>
    <message>
        <location filename="../../../plugins/system/about/privacydialog.cpp" line="11"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/privacydialog.cpp" line="26"/>
        <source>End User License Agreement and Privacy Policy Statement of Kylin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/privacydialog.cpp" line="30"/>
        <source>Dear users of Kylin operating system and relevant products,

   Please read the clauses of the Agreement and the supplementary license (hereinafter collectively referred to as “the Agreement”) and the privacy policy statement for Kylin operating system (hereinafter referred to as “the Statement”). When you click the next step to confirm your complete understanding of the content, it shall indicate that you have accepted the clauses of the Agreement, and the Agreement shall take effect immediately and be legally binding on you and the Company.
   “This product” in the Agreement and the Statement refers to “Kylin operating system software product” developed, produced and released by Kylinsoft Co., Ltd. and used for handling the office work or building the information infrastructure for enterprises and governments. “We” refers to Kylinsoft Co., Ltd. “You” refers to the users who pay the license fee and use the Kylin operating system and relevant products. 

End User License Agreement of Kylin 
Release date of the version: July 30, 2021
Effective date of the version: July 30, 2021 

The Agreement shall include the following content:
I. 	User license 
II. 	Java technology limitations
III. 	Cookies and other technologies
IV. 	Intellectual property clause
V. 	Open source code
VI. 	The third-party software/services
VII. Escape clause
VIII. Integrity and severability of the Agreement
IX. 	Applicable law and dispute settlement

   I. 	User license

   According to the number of users who have paid for this product and the types of computer hardware, we shall grant the non-exclusive and non-transferable license to you, and shall only allow the licensed unit and the employees signing the labor contracts with the unit to use the attached software (hereinafter referred to as “the Software”) and documents as well as any error correction provided by Kylinsoft.
   1.	User license for educational institutions
   In the case of observing the clauses and conditions of the Agreement, if you are an educational institution, your institution shall be allowed to use the attached unmodified binary format software and only for internal use. “For internal use” here refers to that the licensed unit and the employees signing the labor contracts with the unit as well as the students enrolled by your institution can use this product. 
   2.	Use of the font software
   Font software refers to the software pre-installed in the product and generating font styles. You cannot separate the font software from the Software and cannot modify the font software in an attempt to add any function that such font software, as a part of this product, does not have when it is delivered to you, or you cannot embed the font software in the files provided as a commercial product for any fee or other remuneration, or cannot use it in equipment where this product is not installed. If you use the font software for other commercial purposes such as external publicity, please contact and negotiate with the font copyright manufacture to obtain the permissions for your relevant acts.

   II. 	Java technology limitations 

   You cannot change the “Java Platform Interface” (referred to as “JPI”, that is, the classes in the “java” package or any sub-package of the “java” package), whether by creating additional classes in JPI or by other means to add or change the classes in JPI. If you create an additional class as well as one or multiple relevant APIs, and they (i) expand the functions of Java platform; And (ii) may be used by the third-party software developers to develop additional software that may call the above additional APIs, you must immediately publish the accurate description of such APIs widely for free use by all developers. You cannot create or authorize other licensees to create additional classes, interfaces or sub-packages marked as “java”, “javax” and “sun” in any way, or similar agreements specified by Sun in any naming agreements. See the appropriate version of the Java Runtime Environment Binary Code License (located at http://jdk.java.net at present) to understand the availability of runtime code jointly distributed with Java mini programs and applications.

   III. 	Cookies and other technologies

   In order to help us better understand and serve the users, our website, online services and applications may use the “Cookie” technology. Such Cookies are used to store the network traffic entering and exiting the system and the traffic generated due to detection errors, so they must be set. We shall understand how you interact with our website and online services by using such Cookies.
   If you want to disable the Cookie and use the Firefox browser, you may set it in Privacy and Security Center of Firefox. If your use other browsers, please consult the specific schemes from the relevant suppliers. 
   In accordance with Article 76, paragraph 5 of the Network Security Law of the People&apos;s Republic of China, personal information refers to all kinds of information recorded in electronic or other ways, which can identify the natural persons’ personal identity separately or combined with other information, including but not limited to the natural person’s name, date of birth, identity certificate number, personal biological identification information, address and telephone number, etc. If Cookies contain the above information, or the combined information of non-personal information and other personal information collected through Cookie, for the purpose of this privacy policy, we shall regard the combined information as personal privacy information, and shall provide the corresponding security protection measures for your personal information by referring to Kylin Privacy Policy Statement.

   IV. 	Intellectual property clause

   1.	Trademarks and Logos
   This product shall be protected by the copyright law, trademark law and other laws and international intellectual property conventions. Title to the product and all associated intellectual property rights are retained by us or its licensors. No right, title or interest in any trademark, service mark, logo or trade name of us or its licensors is granted under the Agreement. Any use of Kylinsoft marked by you shall be in favor of Kylinsoft, and without our consent, you shall not arbitrarily use any trademark or sign of Kylinsoft.
  2.	Duplication, modification and distribution
   If the Agreement remains valid for all duplicates, you may and must duplicate, modify and distribute software observing GNU GPL-GNU General Public License agreement among the Kylin operating system software products in accordance with GNU GPL-GNU General Public License, and must duplicate, modify and distribute other Kylin operating system software products not observing GNU GPL-GNU General Public License agreement in accordance with relevant laws and other license agreements, but no derivative release version based on the Kylin operating system software products can use any of our trademarks or any other signs without our written consent.
   Special notes: Such duplication, modification and distribution shall not include any software, to which GNU GPL-GNU General Public License does not apply, in this product, such as the software store, input method software, font library software and third-party applications contained by the Kylin operating system software products. You shall not duplicate, modify (including decompilation or reverse engineering) or distribute the above software unless prohibited by applicable laws. 

   V. 	Open source code

   For any open source codes contained in this product, any clause of the Agreement shall not limit, constrain or otherwise influence any of your corresponding rights or obligations under any applicable open source code license or all kinds of conditions you shall observe.

   VI.  The third-party software/services

   The third-party software/services referred to in the Agreement refer to relevant software/services developed by other organizations or individuals other than the Kylin operating system manufacturer. This product may contain or be bundled with the third-party software/services to which the separate license agreements are attached. When you use any third-party software/services with separate license agreements, you shall be bound by such separate license agreements.
   We shall not have any right to control the third-party software/services in these products and shall not expressly or implicitly ensure or guarantee the legality, accuracy, effectiveness or security of the acts of their providers or users.

   VII. 	Escape clause

   1.	Limited warranty
    We guarantee to you that within ninety (90) days from the date when you purchase or obtain this product in other legal ways (subject to the date of the sales contract), the storage medium (if any) of this product shall not be involved in any defects in materials or technology when it is normally used. All compensation available to you and our entire liability under this limited warranty will be for us to choose to replace this product media or refund the fee paid for this product.
   2.	Disclaimer
   In addition to the above limited warranty, the Software is provided “as is” without any express or implied condition statement and warranty, including any implied warranty of merchantability, suitability for a particular purpose or non-infringement, except that this disclaimer is deemed to be legally invalid.
   3.	Limitation of responsibility
   To the extent permitted by law, under any circumstances, no matter what theory of liability is adopted, no matter how it is caused, for any loss of income, profit or data caused by or related to the use or inability to use the Software, or for special indirect consequential incidental or punitive damages, neither we nor its licensors shall be liable (even if we have been informed of the possibility of such damages). According to the Agreement, in any case, whether in contract tort (including negligence) or otherwise, our liability to you will not exceed the amount you pay for the Software. The above limitations will apply even if the above warranty fails of its essential purpose.

   VIII. 	Integrity and severability of the Agreement

   1.	The integrity of the Agreement
  The Agreement is an entire agreement on the product use concluded by us with you. It shall replace all oral or written contact information, suggestions, representations and guarantees inconsistent with the Agreement previous or in the same period. During the period of the Agreement, in case of any conflict clauses or additional clauses in the relevant quotations, orders or receipts or in other correspondences regarding the content of the Agreement between the parties, the Agreement shall prevail. No modification of the Agreement will be binding, unless in writing and signed by an authorized representative of each party.
   2.	Severability of the Agreement
   If any provision of the Agreement is deemed to be unenforceable, the deletion of the corresponding provision will still be effective, unless the deletion will hinder the realization of the fundamental purpose of the parties (in which case, the Agreement will be terminated immediately).

   IX. 	Applicable law and dispute settlement

   1.	Application of governing laws
   Any dispute settlement (including but not limited to litigation and arbitration) related to the Agreement shall be governed by the laws of the People’s Republic of China. The legal rules of any other countries and regions shall not apply.
   2.	Termination
   If the Software becomes or, in the opinion of either party, may become the subject of any claim for intellectual property infringement, either party may terminate the Agreement immediately.
   The Agreement is effective until termination. You may terminate the Agreement at any time, but you must destroy all originals and duplicates of the Software. The Agreement will terminate immediately without notice from us if you fail to comply with any provision of the Agreement. At the time of termination, you must destroy all originals and duplicates of such software, and shall be legally liable for not observing the Agreement.

   The Agreement shall be in both Chinese and English, and in case of ambiguity between any content above, the Chinese version shall prevail.

Privacy Policy Statement of Kylin Operating System
Release date of the version: July 30, 2021
Effective date of the version: July 30, 2021

We attach great importance to personal information and privacy protection. In order to guarantee the legal, reasonable and appropriate collection, storage and use of your personal privacy information and the transmission and storage in the safe and controllable circumstances, we hereby formulate this Statement. We shall provide your personal information with corresponding security protection measures according to the legal requirements and mature security standards in the industry.
   The Statement shall include the following content:
    I. 	Collection and use your personal information
   II. 	How to store and protect your personal information
   III. 	How to manage your personal information
   IV. 	Privacy of the third-party software/services
   V. 	Minors’ use of the products
   VI. 	How to update this Statement
   VII. How to contact us

    I. 	How to collect and use your personal information

   1.	The collection of personal information
   We shall collect the relevant information when you use this product mainly to provide you with higher-quality products, more usability and better services. Part of information collected shall be provided by you directly, and other information shall be collected by us through your interaction with the product as well as your use and experience of the product. We shall not actively collect and deal with your personal information unless we have obtained your express consent according to the applicable legal stipulations.
   1)	The licensing mechanism for this product allows you to apply for the formal license of the product in accordance with the contract and relevant agreements after you send a machine code to the commercial personnel of Kylinsoft, and the machine code is generated through encryption and conversion according to the information of the computer used by you, such as network card, firmware and motherboard. This machine code shall not directly contain the specific information of the equipment, such as network card, firmware and motherboard, of the computer used by you.
   2)	Server of the software store of this product shall connect it according to the CPU type information and IP address of the computer used by you; at the same time, we shall collect the relevant information of your use of the software store of this product, including but not limited to the time of opening the software store, interaction between the pages, search content and downloaded content. The relevant information collected is generally recorded in the log of server system of software store, and the specific storage position may change due to different service scenarios.
   3)	Upgrading and updating of this product shall be connected according to the IP address of the computer used by you, so that you can upgrade and update the system;
   4)	Your personal information, such as E-mail address, telephone number and name, shall be collected due to business contacts and technical services.
   5)	The biological characteristic management tool support system components of this product shall use the biological characteristics for authentication, including fingerprint, finger vein, iris and voiceprint. The biological characteristic information input by you shall be stored in the local computer, and for such part of information, we shall only receive the verification results but shall not collect or upload it. If you do not need to use the biological characteristics for the system authentication, you may disable this function in the biological characteristic management tool.
   6)	This product shall provide the recording function. When you use the recording function of this product, we shall only store the audio content when you use the recording in the local computer but shall not collect or upload the content.
   7)	The service and support functions of this product shall collect the information provided by you for us, such as log, E-mail, telephone and name, so as to make it convenient to provide the technical services, and we shall properly keep your personal information.
   8)	In the upgrading process of this product, if we need to collect additional personal information of yours, we shall timely update this part of content.

  2.	Use of personal information
   We shall strictly observe the stipulations of laws and regulations and agreements with you to use the information collected for the following purposes. In case of exceeding the scope of following purposes, we shall explain to you again and obtain your consent.
   1)	The needs such as product licensing mechanism, use of software store, system updating and maintenance, biological identification and online services shall be involved;
   2)	We shall utilize the relevant information to assist in promoting the product security, reliability and sustainable service;
   3)	We shall directly utilize the information collected (such as the E-mail address and telephone provided by you) to communicate with you directly, for example, business contact, technical support or follow-up service visit;
   4)	We shall utilize the data collected to improve the current usability of the product, promote the product’s user experience (such as the personalized recommendation of software store) and repair the product defects, etc.;
   5)	We shall use the user behavior data collected for data analysis. For example, we shall use the information collected to analyze and form the urban thermodynamic chart or industrial insight report excluding any personal information. We may make the information excluding identity identification content upon the statistics and processing public and share it with our partners, to understand how the users use our services or make the public understand the overall use trend of our services;
   6)	We may use your relevant information and provide you with the advertising more related to you on relevant websites and in applications and other channels;
   7)	In order to follow the relevant requirements of relevant laws and regulations, departmental regulations and rules and governmental instructions.

   3.	Information sharing and provision
   We shall not share or transfer your personal information to any third party, except for the following circumstances:
   1)	After obtaining your clear consent, we shall share your personal information with the third parities;
   2)	In order to achieve the purpose of external processing, we may share your personal information with the related companies or other third-party partners (the third-party service providers, contractors, agents and application developers). We shall protect your information security by means like encryption and anonymization;
    3)	We shall not publicly disclose the personal information collected. If we must disclose it publicly, we shall notify you of the purpose of such public disclosure, type of information disclosed and the sensitive information that may be involved, and obtain your consent;
   4)	With the continuous development of our business, we may carry out the transactions, such as merger, acquisition and asset transfer, and we shall notify you of the relevant circumstances, and continue to protect or require the new controller to continue to protect your personal information according to laws and regulations and the standards no lower than that required by this Statement;
    5)	If we use your personal information beyond the purpose claimed at the time of collection and the directly or reasonably associated scope, we shall notify you again and obtain your consent before using your personal information.

   4.	Exceptions with authorized consent
   1)	It is directly related to national security, national defense security and other national interests;
   2)	It is directly related to public safety, public health and public knowledge and other major public interests;
   3)	It is directly related to crime investigation, prosecution, judgment and execution of judgment;
   4)	It aims to safeguard the life, property and other major legal rights and interests of you or others but it is impossible to obtain your own consent;
   5)	The personal information collected is disclosed to the public by yourself;
   6)	Personal information collected from legally publicly disclosed information, such as legal news reports, government information disclosure and other channels;
   7)	It is necessary to sign and perform of the contract according to your requirement;
   8)	It is necessary to maintain the safe and stable operation of the provided products or services, including finding and handling any fault of products or services;
   9)	It is necessary to carry out statistical or academic research for public interest, and when the results of academic research or description are provided, the personal information contained in the results is de-identified;
   10)	Other circumstances specified in the laws and regulations.

   II. 	How to store and protect personal information

   1.	Information storage place
   We shall store the personal information collected and generated in China within the territory of China in accordance with laws and regulations.
   2.	Information storage duration
  Generally speaking, we shall retain your personal information for the time necessary to achieve the purpose or for the shortest term stipulated by laws and regulations. Information recorded in the log shall be kept for a specified period and be automatically deleted according to the configuration.
   When operation of our product or services stops, we shall notify you in the forms such as notification and announcement, delete your personal information or conduct anonymization within a reasonable period and immediately stop the activities collecting the personal information.
   3.	How to protect the information
   We shall strive to provide guarantee for the users’ information security, to prevent the loss, improper use, unauthorized access or disclosure of the information.
   We shall use the security protection measures within the reasonable security level to protect the information security. For example, we shall protect your system account and password by means like encryption.
   We shall establish the special management systems, processes and organizations to protect the information security. For example, we shall strictly restrict the scope of personnel who access to the information, and require them to observe the confidentiality obligation.
   4.	Emergency response plan
    In case of security incidents, such as personal information disclosure, we shall start the emergency response plan according to law, to prevent the security incidents from spreading, and shall notify you of the situation of the security incidents, the possible influence of the incidents on you and the remedial measures we will take, in the form of pushing the notifications and announcements. We will also report the disposition of the personal information security events according to the laws, regulations and regulatory requirements.

   III. 	How to manage your personal information

   If you worry about the personal information disclosure caused by using this product, you may consider suspending or not using the relevant functions involving the personal information, such as the formal license of the product, application store, system updating and upgrading and biological identification, according to the personal and business needs.
   Please pay attention to the personal privacy protection at the time of using the third-party software/services in this product.

   IV. 	Privacy of the third-party software/services

   The third-party software/services referred to in the Agreement refer to relevant software/services developed by other organizations or individuals other than the Kylin operating system manufacturer.
   When you install or use the third-party software/services in this product, the privacy protection and legal responsibility of the third-party software/services shall be independently borne by the third-party software/services. Please carefully read and examine the privacy statement or clauses corresponding to the third-party software/services, and pay attention to the personal privacy protection.

   V. 	Minors’ use of the products

   If you are a minor, you shall obtain your guardian’s consent on your use of this product and the relevant service clauses. Except for the information required by the product, we shall not deliberately require the minors to provide more data. With the guardians’ consent or authorization, the accounts created by the minors shall be deemed to be the same as any other accounts. We have formulated special information processing rules to protect the personal information security of minors using this product. The guardians shall also take the appropriate preventive measures to protect the minors and supervise their use of this product.

   VI. 	How to update this Statement

   We may update this Statement at any time, and shall display the updated statement to you through the product installation process or the company’s website at the time of updating. After such updates take effect, if you use such services or any software permitted according to such clauses, you shall be deemed to agree on the new clauses. If you disagree on the new clauses, then you must stop using this product, and please close the account created by you in this product; if you are a  guardian, please help your minor child to close the account created by him/her in this product.

   VII. 	How to contact us

  If you have any question, or any complaints or opinions on this Statement, you may seek advice through our customer service hotline 400-089-1870, or the official website (www.kylinos.cn), or “service and support” application in this product. You may also contact us by E-mail (market@kylinos.cn).
   We shall timely and properly deal with them. Generally, a reply will be made within 15 working days.
   The Statement shall take effect from the date of updating. The Statement shall be in Chinese and English at the same time and in case of any ambiguity of any clause above, the Chinese version shall prevail.
   Last date of updating: November 1, 2021

Address: Building 3, Xin’an Entrepreneurship Plaza, Tanggu Marine Science and Technology Park, Binhai High-tech Zone, Tianjin (300450)
             Silver Valley Tower, No. 9, North Forth Ring West Road, Haidian District, Beijing (100190)
             Building T3, Fuxing World Financial Center, No. 303, Section 1 of Furong Middle Road, Kaifu District, Changsha City (410000)
             Digital Entertainment Building, No. 1028, Panyu Road, Xuhui District, Shanghai (200030)
Tel.: Tianjin (022) 58955650       Beijing (010) 51659955
             Changsha (0731) 88280170    Shanghai (021) 51098866
Fax: Tianjin (022) 58955651       Beijing (010) 62800607
             Changsha (0731) 88280166    Shanghai (021) 51062866

Company website: www.kylinos.cn
E-mail: support@kylinos.cn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/privacydialog.cpp" line="231"/>
        <source>Kylinsoft Co., Ltd.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Proxy</name>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="483"/>
        <source>Auto Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Auto Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="485"/>
        <source>Auto url</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Auto url</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="487"/>
        <source>Manual Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Manual Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="489"/>
        <source>Http Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Http Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="496"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="497"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="498"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="499"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="481"/>
        <source>System Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="491"/>
        <source>Https Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Https Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="493"/>
        <source>Ftp Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Ftp Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="495"/>
        <source>Socks Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Socks Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="500"/>
        <source>List of ignored hosts. more than one entry, please separate with english semicolon(;)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="501"/>
        <source>Enable Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="502"/>
        <source>User Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="503"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="506"/>
        <source>Apt Proxy</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Proxy/Apt Proxy</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="507"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="508"/>
        <source>Server Address : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="509"/>
        <source>Port : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="510"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="607"/>
        <source>The apt proxy  has been turned off and needs to be restarted to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="892"/>
        <source>The system needs to be restarted to set the Apt proxy, whether to reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="608"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="893"/>
        <source>Reboot Later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="609"/>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="894"/>
        <source>Reboot Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/proxy/proxy.cpp" line="45"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../main.cpp" line="91"/>
        <source>ukui-control-center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="82"/>
        <source>ukui-control-center is already running!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="186"/>
        <source>Customize Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="458"/>
        <source>Edit Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="167"/>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="204"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="206"/>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="224"/>
        <source>Jan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="225"/>
        <source>Feb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="226"/>
        <source>Mar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="227"/>
        <source>Apr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="229"/>
        <source>Jun</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="230"/>
        <source>Jul</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="231"/>
        <source>Aug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="232"/>
        <source>Sep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="233"/>
        <source>Oct</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="234"/>
        <source>Nov</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="235"/>
        <source>Dec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="256"/>
        <source>Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="771"/>
        <source>blue-crystal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="773"/>
        <source>dark-sense</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="775"/>
        <source>DMZ-Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="777"/>
        <source>DMZ-White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="799"/>
        <source>basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="801"/>
        <source>classical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="803"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="815"/>
        <source>default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="805"/>
        <source>fashion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="807"/>
        <source>hp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="809"/>
        <source>ukui</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="811"/>
        <source>lightseeking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="813"/>
        <source>HeYin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="173"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1025"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="322"/>
        <source>min length %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1035"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="332"/>
        <source>min digit num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1044"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="341"/>
        <source>min upper num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1053"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="350"/>
        <source>min lower num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1062"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="359"/>
        <source>min other num %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1072"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="369"/>
        <source>min char class %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1081"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="378"/>
        <source>max repeat %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1090"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="387"/>
        <source>max class repeat %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="1099"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="396"/>
        <source>max sequence %1
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>January</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>February</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>March</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>April</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/changevalidinteldialog.cpp" line="228"/>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>May</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="33"/>
        <source>June</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>July</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>August</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>September</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>October</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>Novermber</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.cpp" line="34"/>
        <source>December</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="659"/>
        <source>xxx客户端</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResolutionSlider</name>
    <message>
        <location filename="../../../plugins/system/display_hw/resolutionslider.cpp" line="111"/>
        <source>No available resolutions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screenlock</name>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="26"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="45"/>
        <source>Screenlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="80"/>
        <source>Screenlock Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="211"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="116"/>
        <source>Show picture of screenlock on screenlogin</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screenlock/Show picture of screenlock on screenlogin</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="281"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="118"/>
        <source>Lock screen when screensaver boot</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screenlock/Lock screen when screensaver boot</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="364"/>
        <source>Lock screen delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="448"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="120"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screenlock/Browse</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="455"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="122"/>
        <source>Online Picture</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screenlock/Online Picture</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.ui" line="487"/>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="131"/>
        <source>Reset To Default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screenlock/Reset To Default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="148"/>
        <source>1m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="148"/>
        <source>5m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="148"/>
        <source>10m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="148"/>
        <source>30m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="148"/>
        <source>45m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>1h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>1.5h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>3h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>2h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="149"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="459"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="501"/>
        <source>select custom wallpaper file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="502"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="503"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="504"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="505"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screenlock/screenlock.cpp" line="506"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Screensaver</name>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="59"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="96"/>
        <source>Screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="201"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="197"/>
        <source>Idle time</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screensaver/Idle time</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="475"/>
        <source>Lock screen when activating screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.ui" line="297"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="195"/>
        <source>Screensaver program</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Screensaver/Screensaver program</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="183"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="850"/>
        <source>Text(up to 30 characters):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="884"/>
        <source>Show rest time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="224"/>
        <source>UKUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="225"/>
        <source>Blank_Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="236"/>
        <source>Customize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="251"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="753"/>
        <source>5min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="251"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="754"/>
        <source>10min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="251"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="755"/>
        <source>30min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="251"/>
        <source>15min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="251"/>
        <source>1hour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="252"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="655"/>
        <source>Screensaver source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="661"/>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="711"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="669"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp *.svg)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="710"/>
        <source>select custom screensaver dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="712"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="713"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="714"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="715"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="748"/>
        <source>Switching time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="752"/>
        <source>1min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="800"/>
        <source>Ordinal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="801"/>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="809"/>
        <source>Random switching</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="903"/>
        <source>Text position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="911"/>
        <source>Centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/screensaver/screensaver.cpp" line="912"/>
        <source>Randow(Bubble text)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShareMain</name>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="57"/>
        <source>Remote Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="66"/>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="435"/>
        <source>Allow others to view your desktop</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Vino/Allow others to view your desktop</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="81"/>
        <source>Allow connection to control screen</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Vino/Allow connection to control screen</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="96"/>
        <source>You must confirm every visit for this machine</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Vino/You must confirm every visit for this machine</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino/sharemain.cpp" line="111"/>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="455"/>
        <source>Require user to enter this password: </source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Vino/Require user to enter this password:</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="240"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="240"/>
        <source>please select an output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="302"/>
        <source>Input Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="303"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="395"/>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="410"/>
        <source>Password length must be less than or equal to 8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="402"/>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="457"/>
        <source>Password can not be blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="419"/>
        <source>Share</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="446"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="473"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="485"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="495"/>
        <source>Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="497"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="499"/>
        <source>Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="525"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="527"/>
        <source>ViewOnly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="535"/>
        <source>Client Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="546"/>
        <source>Client Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="560"/>
        <source>Client IP：</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="691"/>
        <source>退出程序</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/vino_hw/sharemain.cpp" line="691"/>
        <source>确认退出程序！</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Shortcut</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.ui" line="50"/>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="163"/>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="177"/>
        <source>System Shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Shortcut/System Shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.ui" line="103"/>
        <source>Custom Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="79"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="160"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Shortcut/Add</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="165"/>
        <source>Customize Shortcut</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Shortcut/Customize Shortcut</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="725"/>
        <source> or </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="442"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/shortcut.cpp" line="443"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Theme</name>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="79"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="170"/>
        <source>Window Theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Theme/Window Theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="364"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="172"/>
        <source>Icon theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Theme/Icon theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="440"/>
        <source>Control theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="515"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="174"/>
        <source>Cursor theme</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Theme/Cursor theme</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="591"/>
        <source>Effect setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="670"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="176"/>
        <source>Performance mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Theme/Performance mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="754"/>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="178"/>
        <source>Transparency</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Theme/Transparency</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.ui" line="869"/>
        <source>Reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="113"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="251"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="252"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/theme/theme.cpp" line="253"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeBtn</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="79"/>
        <source>Tomorrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="81"/>
        <source>Yesterday</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="83"/>
        <source>Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="101"/>
        <source>%1 hours earlier than local</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/timeBtn.cpp" line="103"/>
        <source>%1 hours later than local</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeZoneChooser</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="35"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="36"/>
        <source>Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="44"/>
        <source>Change time zone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="68"/>
        <source>Search Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="105"/>
        <source>Change Timezone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/worldMap/timezonechooser.cpp" line="133"/>
        <source>To select a time zone, please click where near you on the map and select a city from the nearest city</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Touchpad</name>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpad.cpp" line="31"/>
        <source>Touchpad</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TouchpadUI</name>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="39"/>
        <source>Touchpad Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="51"/>
        <source>Disable touchpad when using the mouse</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Touchpad/Disable touchpad when using the mouse</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="70"/>
        <source>Slow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="71"/>
        <source>Fast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="95"/>
        <source>Disable touchpad when typing</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Touchpad/Disable touchpad when typing</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="113"/>
        <source>Touch and click on the touchpad</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Touchpad/Touch and click on the touchpad</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="131"/>
        <source>Scroll bar slides with finger</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Touchpad/Scroll bar slides with finger</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="148"/>
        <source>Scrolling area</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Touchpad/Scrolling area</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="152"/>
        <source>Disable scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="151"/>
        <source>Edge scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="68"/>
        <source>Pointer Speed</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Touchpad/Pointer Speed</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/devices/touchpad/touchpadui.cpp" line="150"/>
        <source>Two-finger scrolling in the middle area</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrialDialog</name>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="12"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="37"/>
        <source>Yinhe Kylin OS(Trail Version) Disclaimer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="46"/>
        <source>Dear customer:
    Thank you for trying Yinhe Kylin OS(trail version)! This version is free for users who only try out, no commercial purpose is permitted. The trail period lasts one year and it starts from the ex-warehouse time of the OS. No after-sales service is provided during the trail stage. If any security problems occurred when user put important files or do any commercial usage in system, all consequences are taken by users. Kylin software Co., Ltd. take no legal risk in trail version.
    During trail stage,if you want any technology surpport or activate the system, please buy“Yinhe Kylin Operating System”official version or authorization by contacting 400-089-1870.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="58"/>
        <source>Kylin software Co., Ltd.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/about/trialdialog.cpp" line="66"/>
        <source>www.Kylinos.cn</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UkccAbout</name>
    <message>
        <location filename="../../ukccabout.cpp" line="60"/>
        <location filename="../../ukccabout.cpp" line="82"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="89"/>
        <source>Version: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="96"/>
        <source>The control panel provides a friendly graphical user interface to manage common configuration items of the operating system. System configuration provides system, equipment, personalization, network, account, time and date, account, time and date, update, notification and operation module operations. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ukccabout.cpp" line="104"/>
        <source>Service and Support:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UnifiedOutputConfig</name>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="79"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="75"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="114"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="104"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="119"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="109"/>
        <source>arrow-up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="120"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="110"/>
        <source>90° arrow-right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="121"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="111"/>
        <source>arrow-down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="122"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="112"/>
        <source>90° arrow-left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="154"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="141"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/unifiedoutputconfig.cpp" line="335"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="146"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="312"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="172"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="282"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="288"/>
        <location filename="../../../plugins/system/display_hw/unifiedoutputconfig.cpp" line="325"/>
        <source>%1 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserInfo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="41"/>
        <source>Current User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="309"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="147"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Password</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="331"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="149"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="188"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Type</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="353"/>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="422"/>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="151"/>
        <source>Login no passwd</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Login no passwd</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="153"/>
        <source>enable autoLogin</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/enable autoLogin</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="500"/>
        <source>Automatic login at boot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.ui" line="568"/>
        <source>Other Users</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="71"/>
        <source>User Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="862"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="863"/>
        <source>The system only allows one user to log in automatically.After it is turned on, the automatic login of other users will be turned off.Is it turned on?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="866"/>
        <source>Trun on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="867"/>
        <source>Close on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="890"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="892"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="894"/>
        <source>root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="156"/>
        <source>CurrentUser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="157"/>
        <source>OthersUser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="184"/>
        <source>Passwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="192"/>
        <source>Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="245"/>
        <source>LoginWithoutPwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="265"/>
        <source>AutoLoginOnBoot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="492"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/userinfo.cpp" line="492"/>
        <source>The user is logged in, please delete the user after logging out</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserInfoIntel</name>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="83"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="146"/>
        <source>Current User</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Current User</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="301"/>
        <source>Change phone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="346"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="157"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="1125"/>
        <source>Change pwd</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Change pwd</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="397"/>
        <source>User group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="423"/>
        <source>Del user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="510"/>
        <source>system reboot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="565"/>
        <source>Unclosed apps start after a restart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.ui" line="634"/>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="149"/>
        <source>Other Users</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Other Users</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="61"/>
        <source>User Info Intel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="152"/>
        <source>Change Tel</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Change Tel</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="180"/>
        <source>Delete user</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Userinfo/Delete user</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="193"/>
        <source>standard user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="195"/>
        <source>administrator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="204"/>
        <source>root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="434"/>
        <source>Add new user</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="736"/>
        <source>set pwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo_intel/userinfo_intel.cpp" line="750"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UtilsForUserinfo</name>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="31"/>
        <source>Passwd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="34"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="37"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="198"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/account/userinfo/utilsforuserinfo.cpp" line="200"/>
        <source>Admin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vino</name>
    <message>
        <location filename="../../../plugins/system/vino/vino.cpp" line="25"/>
        <location filename="../../../plugins/system/vino_hw/vino_hw.cpp" line="25"/>
        <source>Vino</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Vpn</name>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.ui" line="53"/>
        <source>Add Vpn Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.cpp" line="28"/>
        <source>Vpn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/network/vpn/vpn.cpp" line="102"/>
        <source>Add vpn connect</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Vpn/Add vpn connect</extra-contents_path>
    </message>
</context>
<context>
    <name>Wallpaper</name>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="103"/>
        <source>Desktop Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="398"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="537"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="126"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Wallpaper/Browse</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="544"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="128"/>
        <source>Online Picture</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Wallpaper/Online Picture</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="576"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="137"/>
        <source>Reset To Default</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Wallpaper/Reset To Default</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.ui" line="331"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="51"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="124"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="152"/>
        <source>picture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="152"/>
        <source>color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="168"/>
        <source>scaled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="168"/>
        <source>wallpaper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="168"/>
        <source>centered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="168"/>
        <source>stretched</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="482"/>
        <source>Wallpaper files(*.jpg *.jpeg *.bmp *.dib *.png *.jfif *.jpe *.gif *.tif *.tiff *.wdp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="522"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="564"/>
        <source>select custom wallpaper file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="523"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="565"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="524"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="566"/>
        <source>Position: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="525"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="567"/>
        <source>FileName: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="526"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="568"/>
        <source>FileType: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="527"/>
        <location filename="../../../plugins/personalized/wallpaper/wallpaper.cpp" line="569"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="824"/>
        <source>night mode</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/Display/night mode</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="832"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="649"/>
        <source>Theme follow night mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="868"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1042"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="671"/>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="546"/>
        <source>screen zoom</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/screen zoom</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="556"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="557"/>
        <source>Some applications need to be logouted to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="637"/>
        <source>Mirror Display</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/unify output</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="672"/>
        <source>After modifying the resolution or refresh rate, due to compatibility issues between the display device and the graphics card, the display may be abnormal or unable to display
the settings will be saved after 29 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="676"/>
        <source>Save Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="677"/>
        <source>Restore Config</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="685"/>
        <source>After modifying the resolution or refresh rate, due to compatibility issues between the display device and the graphics card, the display may be abnormal or unable to display 
the settings will be saved after %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="1525"/>
        <source>Warnning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="2066"/>
        <source>All Day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="2066"/>
        <source>Follow the sunrise and sunset(17:55-06:23)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="2333"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="2347"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="2151"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="2158"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="725"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="543"/>
        <source>monitor</source>
        <translation type="unfinished"></translation>
        <extra-contents_path>/display/monitor</extra-contents_path>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1381"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1557"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="1564"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="1515"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="1811"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1557"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="1811"/>
        <source>please insure at least one output!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1382"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="1516"/>
        <source>Open time should be earlier than close time!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="274"/>
        <source>Night Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="294"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="309"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="325"/>
        <location filename="../../../plugins/system/display/widget.cpp" line="2066"/>
        <source>Custom Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="336"/>
        <source>to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="362"/>
        <source>Color Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="365"/>
        <source>Warmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="368"/>
        <source>Colder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="696"/>
        <source>Multi-screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="701"/>
        <source>First Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="704"/>
        <source>Clone Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="703"/>
        <source>Extend Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="702"/>
        <source>Vice Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="859"/>
        <source>resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="862"/>
        <source>orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="865"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="869"/>
        <source>The screen %1 has been modified, whether to save it ? &lt;br/&gt;&lt;font style= &apos;color:#626c6e&apos;&gt;the settings will be saved after 14 seconds&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="872"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="873"/>
        <source>Not Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="882"/>
        <source>The screen %1 has been modified, whether to save it ? &lt;br/&gt;&lt;font style= &apos;color:#626c6e&apos;&gt;the settings will be saved after %2 seconds&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1043"/>
        <source>The zoom function needs to log out to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1044"/>
        <source>Log out now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1045"/>
        <source>Later</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/system/display/widget.cpp" line="1565"/>
        <location filename="../../../plugins/system/display_hw/widget.cpp" line="1526"/>
        <source>Sorry, your configuration could not be applied.
Common reasons are that the overall screen size is too big, or you enabled more displays than supported by your GPU.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>addShortcutDialog</name>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="88"/>
        <source>Exec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="126"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="158"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="197"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="309"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="359"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="207"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.ui" line="378"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="64"/>
        <source>Add Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="76"/>
        <source>Please enter a shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="199"/>
        <source>Desktop files(*.desktop)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="206"/>
        <source>select desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="227"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="246"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="257"/>
        <source>Invalid application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="229"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="242"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="253"/>
        <source>Shortcut conflict</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="231"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="244"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="255"/>
        <source>Invalid shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="233"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="240"/>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="259"/>
        <source>Name repetition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/devices/shortcut/addshortcutdialog.cpp" line="265"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>changtimedialog</name>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="32"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="115"/>
        <source>current date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="200"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="321"/>
        <source>year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="398"/>
        <source>month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="472"/>
        <source>day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="574"/>
        <source>cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../../plugins/time-language/datetime/changtime.ui" line="593"/>
        <source>confirm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
