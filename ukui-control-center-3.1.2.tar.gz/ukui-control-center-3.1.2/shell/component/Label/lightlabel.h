#ifndef LIGHTLABEL_H
#define LIGHTLABEL_H
#include <QLabel>
#include "fixlabel.h"

class LightLabel : public FixLabel
{
    Q_OBJECT
public:
    explicit LightLabel(QWidget *parent = nullptr);
    explicit LightLabel(QString text , QWidget *parent = nullptr);
    ~LightLabel();

protected:
    void paintEvent(QPaintEvent *event);
};

#endif // LIGHTLABEL_H
