#ifndef KPINYIN_H
#define KPINYIN_H


#include <QHash>
#include <QString>


QString Chinese2Pinyin(const QString& words);
#endif // KPINYIN_H
