#ifndef METATYPES_H
#define METATYPES_H

#include <QMap>

typedef QMap<QString, QString> CustomData;
Q_DECLARE_METATYPE(CustomData);

#endif // METATYPES_H
